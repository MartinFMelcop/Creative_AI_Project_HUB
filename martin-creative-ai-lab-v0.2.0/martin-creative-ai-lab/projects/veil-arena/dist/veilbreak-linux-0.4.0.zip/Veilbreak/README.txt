Veilbreak 0.4.0 — The Bell Warden

Linux x86_64 desktop prototype. Extract the entire Veilbreak folder, then run
./veilbreak.x86_64 (or open it from your file manager). Keep veilbreak.pck beside it.
Godot, .NET, Python, Node and the source checkout are not required to play.
Your operating system still needs a display/audio stack and OpenGL 3.3 support.
If an archive tool drops the executable permission: chmod +x veilbreak.x86_64

Keyboard: WASD/arrows move; J blade; K seal; Space dodge; Enter begin/resume/restart;
Escape pause; F1 tactics; M sound. Close the window to exit.
Mapped gamepad: left stick/D-pad move; west (X) blade; north (Y) seal; east (B) dodge;
south (A) begin/resume/restart; Start pause; Back tactics; RB sound.
The blade/seal aim toward the Warden when preparation begins. Press per action;
holding a combat button does not repeat. Controller loss pauses; resume explicitly.

This is an evaluation prototype. Physical controller models, other platforms,
independent enjoyment/accessibility and commercial readiness remain unverified.
Godot and its third-party notices accompany the engine. ASSET-PROVENANCE.json
records AI-generated paintings and original synthesized audio; no new project
license, exclusive rights or commercial clearance is granted by this package.
Source and author context: https://github.com/MartinFMelcop/Creative_AI_Project_HUB
