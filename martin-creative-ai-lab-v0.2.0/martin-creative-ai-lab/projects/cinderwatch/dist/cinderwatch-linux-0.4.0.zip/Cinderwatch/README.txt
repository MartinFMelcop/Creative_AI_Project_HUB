Cinderwatch 0.4.0 — Linux x86_64 tactical rescue prototype

Extract the ENTIRE Cinderwatch folder, then run ./cinderwatch.x86_64.
Keep cinderwatch.pck, data_Cinder.Native_linuxbsd_x86_64 and media beside it.
Godot, an installed .NET runtime, SDK, Python and source checkout are unnecessary.
If your extractor drops permissions: chmod +x cinderwatch.x86_64
The OS still needs desktop/audio libraries, ICU and OpenGL 3.3 or a compatible driver.
Consult the repository execution evidence for tested distributions and limits.

Read the brief. Enter the yard, inspect announced threats and choose an action.
Confirm spends one turn. Resolve advances the named enemy; inspection spends none.
Tab/Shift+Tab and Enter navigate/activate controls. Tactics explains rows, Cover,
Pin, scorch and supplies. Choose salvage between the three encounters; damage and
resources carry forward. Sound toggles above the brief. Close the window to exit.

Accepted actions autosave to Godot's per-user Cinderwatch directory, shared with
the previous native project. Resume validates/replays them; New run starts fresh
memory and replaces the slot only after a turn or explicit Save. No undo/cloud save.
The original rules/save version remains 0.1.0. Keep a private copy of your save.

For technical verification only (all input is scripted, not a human playtest):
./cinderwatch.x86_64 --headless -- --verify --save-path /tmp/cinder-check/save.json
Always use an isolated path: verification replaces that specified test save.

BUILD-INFO.json identifies sources/runtime and hashes; media/provenance.json records
original generated portraits and synthesized cues. Godot/.NET notices are included.
Source/author context: https://github.com/MartinFMelcop/Creative_AI_Project_HUB
No independent play, hardware listening/accessibility or commercial approval is claimed.
