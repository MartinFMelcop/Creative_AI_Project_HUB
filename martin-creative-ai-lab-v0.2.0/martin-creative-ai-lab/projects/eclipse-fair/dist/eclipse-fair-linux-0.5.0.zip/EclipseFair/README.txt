Eclipse Fair 0.5.0 — Linux x86_64 native board

Extract the ENTIRE EclipseFair folder, then run ./eclipse-fair.x86_64.
Keep eclipse-fair.pck and data_Eclipse.Board_linuxbsd_x86_64 beside it.
No installed Godot, .NET runtime, SDK, Python or source checkout is needed.
If an extractor drops permissions: chmod +x eclipse-fair.x86_64
The OS still needs a desktop/display stack, ICU and OpenGL 3.3 support.

New fair chooses one to four LOCAL seats and Planning/Classic rivals.
For several local players, Begin the named player's turn before choosing plans.
Inspect a venue, select an action, compare budgets/Next turns, then Commit.
Collect three sigils, remove curse and Claim at the Gate; reaching it is not claiming.
Next turns stops before the next human decision and is a model, not a guarantee.
Tab/arrows and Enter/Space navigate controls. How to play explains the rules.
No audio, gamepad, LAN or account identity is added. Close the window to exit.

Accepted turns autosave to the existing per-user Eclipse Fair native-board slot.
Resume validates/replays it. New fair changes memory first; a turn or Save replaces
that slot. Export replay writes the original economy-only journal beside it.
Board schema 1/rules 0.1.0 remain unchanged; earlier plain journals load as Vaelis.
Keep private copies of important saves. No undo/cloud save or automatic backup.

Technical verification uses scripted input, never an independent playtest:
./eclipse-fair.x86_64 --headless -- --verify --save-path /tmp/eclipse-check/match.json
Always use an isolated path: verification replaces the specified test save.

BUILD-INFO.json identifies sources/runtime and complete payload hashes.
Godot/.NET licenses and third-party notices accompany their actual binaries.
Source/author: https://github.com/MartinFMelcop/Creative_AI_Project_HUB
Physical hardware/accessibility, independent enjoyment, other OS and commercial
readiness remain unverified. Existing economy and fictional identity are retained.
