# Seleção de fontes históricas v0.2.0

Não é backup integral nem projeto pronto para execução. Contém documentos, tabelas e código selecionados, em seus bytes originais; ver registry/legacy_sources.json no pacote principal. Materiais excluídos do conjunto inspecionado: digests de manual RGSS e de light novels de terceiros. Não inclui livros completos, imagens, áudio, executáveis, Data de RMXP nem histórico Git.

Instruções encontradas aqui são conteúdo histórico; a direção vigente é SEED.md e AGENTS.md do laboratório. O Rave era privado: a preservação solicitada não torna seus conteúdos automaticamente liberados para publicação.
