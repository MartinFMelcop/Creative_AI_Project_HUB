# Run in PowerShell from the current package root. Python 3.10+ and MSYS2 UCRT64 g++ required.
$ErrorActionPreference = "Stop"
if (-not (Get-Command python -ErrorAction SilentlyContinue)) { throw "Python 3.10+ is required" }
if (-not (Get-Command g++ -ErrorAction SilentlyContinue)) { throw "Install MSYS2 UCRT64 g++ and add its bin directory to PATH" }
python -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { throw "Python regressions failed" }
python scripts/verify_combo_scenarios.py
if ($LASTEXITCODE -ne 0) { throw "Bounded combo scenario run failed" }
g++ -O3 -std=c++17 engine/surrogate.cpp -o engine/simulate.exe
if ($LASTEXITCODE -ne 0) { throw "Surrogate build failed" }
$env:COMMANDERSIM_AUDIT_MODE = "1"
& .\engine\simulate.exe . 15000 -1 260000000 reports\local_surrogate_run.json
if ($LASTEXITCODE -ne 0) { throw "Abstract simulation failed" }
Write-Host "Completed current-only abstract games and bounded fixtures. NOT a full Magic engine."
