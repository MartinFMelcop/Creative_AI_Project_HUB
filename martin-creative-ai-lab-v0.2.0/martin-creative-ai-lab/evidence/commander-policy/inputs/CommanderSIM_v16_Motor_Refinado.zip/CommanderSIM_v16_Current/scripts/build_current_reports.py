"""Recalculate current-only research artefacts from executed experiment bytes."""
from __future__ import annotations
from collections import Counter
from pathlib import Path
import hashlib,csv,json,math,datetime
ROOT=Path(__file__).resolve().parents[1]
REPORT=ROOT/'reports'
raw=json.loads((REPORT/'surrogate_policy_pair_v16.json').read_text())
N=raw['phases'][0]['games']
assert N==raw['phases'][1]['games'] and N>0

def ci(x,n):
    p=x/n;se=math.sqrt(p*(1-p)/n)
    return [max(0,p-1.96*se),min(1,p+1.96*se)]

def quantile(hist,q):
    count=sum(hist);target=math.ceil(q*count);x=0
    for i,n in enumerate(hist):
        x+=n
        if x>=target:return i
    return '128_plus'

paired=raw['paired_outcomes']
pp=[]
for seat in range(4):
    gain=sum(paired[a][seat] for a in range(5) if a!=seat)
    loss=sum(paired[seat][b] for b in range(5) if b!=seat)
    effect=(gain-loss)/N
    var=((gain+loss)/N-effect**2)/N
    half=1.96*math.sqrt(var)
    pp.append({'seat':seat+1,'policy_delta_pp':round(100*effect,5),
               'paired_ci95_pp':[round(100*(effect-half),5),round(100*(effect+half),5)],
               'gains':gain,'losses':loss,'paired_trials':N})
summary={'scope':'CURRENT_LISTS_POLICY_COMPARISON_SURROGATE_ONLY',
         'complete_rules_verified_games':0,'surrogate_four_player_games':N*2,
         'bounded_scenarios_not_games':6,'paired_policy_trials':N,
         'constant_decks_all_four_seats':True,'identical_decks_between_conditions':True,
         'deck_changes_this_cycle':0,
         'fixed_seed_pair_offset':raw['metadata']['seed_pair_offset'],
         'paired_policy_effects':pp,'phases':[]}
for phase in raw['phases']:
    games=phase['games'];win=[]
    for item in phase['wins']:
        w=item['wins'];r=w/games
        win.append({'seat':item['deck'],'wins':w,'win_rate_pct':round(100*r,5),
                    'gap_to_25pp':round(100*r-25,5),
                    'ci95_win_rate_pct':[round(100*v,4) for v in ci(w,games)]})
    summary['phases'].append({'policy':phase['phase'],'games':games,'winner_count':sum(w['wins'] for w in phase['wins']),
                              'legitimate_draws_verified':0,'unresolved_surrogate':phase['unresolved_surrogate'],
                              'mean_rounds':phase['mean_rounds'],'p90_rounds':quantile(phase['round_histogram'],.90),
                              'p99_rounds':quantile(phase['round_histogram'],.99),
                              'start_counts':phase['starting_counts'],'wins':win,
                              'max_absolute_gap_from_25pp':max(abs(w['gap_to_25pp']) for w in win)})
(REPORT/'current_kpis.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
with (REPORT/'current_card_scores.csv').open('w',newline='',encoding='utf-8') as f:
    wr=csv.writer(f);wr.writerow(['seat','card','role','land','commander','drawn','played','games',
                                 'drawn_per_game','played_per_game','observed_utility_per_play','denied_value_proxy',
                                 'source_engine','interpretation'])
    for card in raw['phases'][1]['card_events']:
        wr.writerow([card['deck'],card['card'],card['role'],card['land'],card['commander'],
                     card['drawn'],card['played'],N,round(card['drawn']/N,6),round(card['played']/N,6),
                     round(card['observed_utility_total']/card['played'],6) if card['played'] else '',
                     card['denied_value_proxy'],'SURROGATE_ONLY',
                     'observed_utility_is_not_counterfactual_strength'])

# No APIs may be represented as verified without data actually retrieved.
names=Counter()
for seat,stem in enumerate(['01_Dralnu','02_Palladia','03_Belakor','04_Abzan']):
    for line in (ROOT/'decks'/f'{stem}.txt').read_text().splitlines():
        qty,card=line.strip().split(' ',1);names[card]+=int(qty)
assert sum(names.values())==400
refs={"Lich's Mastery":'https://magic.wizards.com/en/news/feature/dominaria-release-notes',
      'Sheoldred, the Apocalypse':'https://www.mtg.wtf/card/dmu/290/Sheoldred-the-Apocalypse',
      "Thassa's Oracle":'https://www.mtg.wtf/card/mb2/175/Thassas-Oracle',
      'Psychosis Crawler':'https://scryfall.com/search?q=%21%22Psychosis+Crawler%22'}
ledger={'scryfall_api_status':'NOT_RETRIEVED','scryfall_api_cards_verified':0,
        'unique_names':len(names),'all_cards_present_count':400,
        'notes':'Public external references do not substitute for complete Scryfall collection API validation.',
        'cards':[{'name':k,'count_in_all_four_decks':v,'scryfall_status':'UNVERIFIED_SCRYFALL',
                  'supplemental_public_source':refs.get(k)} for k,v in sorted(names.items())]}
(REPORT/'card_source_ledger.json').write_text(json.dumps(ledger,indent=2,ensure_ascii=False))
files=['decks/01_Dralnu.txt','decks/02_Palladia.txt','decks/03_Belakor.txt','decks/04_Abzan.txt',
       'profiles.csv','engine/surrogate.cpp','engine/stack_combo_slice.py','engine/legal_priority_slice.py',
       'engine/lich_sheoldred_bounded.py']
man={'project':'CommanderSIM current only','created_date_utc':'2026-10-28',
     'oracle_complete_games':0,'decks':[],
     'game_engine_label':'SURROGATE_ONLY','rule_slice_label':'BOUNDED_NOT_FULL_GAME',
     'current_source_hashes_sha256':{},'raw_run_path':'reports/surrogate_policy_pair_v16.json',
     'raw_run_sha256':hashlib.sha256((REPORT/'surrogate_policy_pair_v16.json').read_bytes()).hexdigest(),
     'scryfall_full_audit':False,'original_deck_archives_included':False}
for seat,stem,cmds in ((1,'01_Dralnu',['Dralnu, Lich Lord']),
                       (2,'02_Palladia',['Palladia-Mors, the Ruiner']),
                       (3,'03_Belakor',["Be'lakor, the Dark Master"]),
                       (4,'04_Abzan',['Livio, Oathsworn Sentinel','Ikra Shidiqi, the Usurper'])):
    src=ROOT/'decks'/f'{stem}.txt'
    man['decks'].append({'seat':seat,'file':f'{stem}.txt','card_count':100,'commanders':cmds,
                         'sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
for path in files:
    man['current_source_hashes_sha256'][path]=hashlib.sha256((ROOT/path).read_bytes()).hexdigest()
(ROOT/'manifest.json').write_text(json.dumps(man,indent=2,ensure_ascii=False))

# The 2-card core requires both specific cards in a randomized 99-card library;
# no mulligan, tutor, or availability conditional probability is inferred.
maths={'interpretation':'HYPERGEOMETRIC_DRAW_ONLY_NOT_WIN_PROBABILITY',
       'population_99_noncommander_cards':99,
       'core_cards':["Sheoldred, the Apocalypse","Lich's Mastery"],
       'formula':'P(both in first k cards)=k*(k-1)/(99*98)',
       'examples':[{'draws_seen':k,'probability_both_seen_pct':round(100*k*(k-1)/(99*98),4)}
                   for k in (7,12,17,22,27)]}
(REPORT/'combo_draw_probabilities.json').write_text(json.dumps(maths,indent=2))
print(json.dumps({'unique_names':len(names),'games':N*2,'scenarios':5,
                  'policy_effects':pp,'winrates':[[v['win_rate_pct'] for v in phase['wins']] for phase in summary['phases']]},indent=2))
