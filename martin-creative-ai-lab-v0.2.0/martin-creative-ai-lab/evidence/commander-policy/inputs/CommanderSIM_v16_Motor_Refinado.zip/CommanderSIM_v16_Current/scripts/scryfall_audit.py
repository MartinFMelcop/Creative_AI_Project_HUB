"""Audit only the four active TXT decklists via Scryfall's collection endpoint.
No card data is guessed on DNS/HTTP failure. Python 3.10+, standard library only.
"""
import json,sys,urllib.request,urllib.error,datetime,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
API='https://api.scryfall.com/cards/collection'
OUT=ROOT/'reports'/'scryfall_legality_audit.json'
def main():
    items=[]
    for path in sorted((ROOT/'decks').glob('*.txt')):
        for line in path.read_text(encoding='utf-8').splitlines():
            n,name=line.split(' ',1)
            if int(n)<1:raise ValueError('Nonpositive card count')
            items.append(name)
    names=sorted(set(items)); collected={};errors=[]
    for k in range(0,len(names),75):
        chunk=names[k:k+75]
        payload=json.dumps({'identifiers':[{'name':n} for n in chunk]}).encode()
        req=urllib.request.Request(API,data=payload,headers={'Content-Type':'application/json','User-Agent':'CommanderSIM research (local, noncommercial)'},method='POST')
        try:
            with urllib.request.urlopen(req,timeout=20) as response: content=json.load(response)
            for card in content.get('data',[]):
                key=card['name'];collected[key]={
                    'oracle_id':card.get('oracle_id'), 'scryfall_id':card.get('id'),
                    'color_identity':card.get('color_identity'),
                    'mana_value':card.get('cmc'),
                    'type_line':card.get('type_line'),
                    'legal_commander':card.get('legalities',{}).get('commander'),
                    'oracle_text':card.get('oracle_text'),
                    'source_uri':card.get('uri'),
                    'status':'FETCHED_UNVERIFIED_DECK_LEGALITY'
                }
            errors.extend([x.get('name',repr(x)) for x in content.get('not_found',[])])
        except Exception as exc:errors.append(f'batch_{k//75}: {type(exc).__name__}: {exc}')
    result={'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':API,'decks':4,'unique_names':len(names),'fetched':len(collected),'unresolved':[{'name':n,'status':'UNVERIFIED'} for n in names if n not in collected],'cards':collected,'errors':errors,'note':'Individually fetched card identities still require final deck-wide color identity, partner, and official banlist checks.'}
    OUT.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(f'Scryfall names: {len(collected)}/{len(names)} fetched; {len(result["unresolved"])} unresolved; status={"PARTIAL" if len(collected)<len(names) else "FETCHED"}')
    return 0 if len(collected)==len(names) else 2
if __name__=='__main__':sys.exit(main())
