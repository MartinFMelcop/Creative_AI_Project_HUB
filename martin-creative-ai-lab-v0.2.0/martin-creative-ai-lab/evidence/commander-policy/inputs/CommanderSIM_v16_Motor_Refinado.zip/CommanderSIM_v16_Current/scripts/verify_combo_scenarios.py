"""Generate five reproducible bounded-scenario traces; not full Magic games."""
import sys, json, hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'engine'))
from stack_combo_slice import ComboTable


def make_scenario(name):
    g=ComboTable(HERE/'decks',seed=20261028,active_seat=0)
    if name in ('core_loop','crawler_finishes','crawler_counterplay','rift_interruption'):
        for c in ["Lich's Mastery", 'Sheoldred, the Apocalypse']:
            g.fixture_permanent(0,c)
        if name in ('crawler_finishes','crawler_counterplay'):g.fixture_permanent(0,'Psychosis Crawler')
        g.fixture_library_count(0,40 if name in ('crawler_finishes','crawler_counterplay') else 6)
        if name=='rift_interruption':
            g.fixture_hand(2,'Cyclonic Rift');g.fixture_mana(2,C=6,U=1)
        if name=='crawler_counterplay':
            g.fixture_hand(3,'Generous Gift');g.fixture_mana(3,C=2,W=1)
        g.start_fixture_draw(0)
        if name=='crawler_counterplay':
            for _ in range(3):g.perform(g.priority,{'kind':'pass'})
            g.perform(3,{'kind':'cast','card':'Generous Gift','target_seat':0,'target_card':'Psychosis Crawler'})
        if name=='rift_interruption':
            g.perform(0,{'kind':'pass'});g.perform(1,{'kind':'pass'})
            g.perform(2,{'kind':'cast','card':'Cyclonic Rift','mode':'overload'})
        g.run_passes(1500)
    elif name in ('oracle_wins','oracle_counterplay'):
        g.fixture_hand(0,"Thassa's Oracle")
        g.fixture_library_count(0,2);g.fixture_mana(0,U=2)
        if name=='oracle_counterplay':
            g.fixture_hand(3,'Generous Gift');g.fixture_mana(3,C=2,W=1)
        g.perform(0,{'kind':'cast','card':"Thassa's Oracle"})
        if name=='oracle_counterplay':
            for _ in range(4):g.perform(g.priority,{'kind':'pass'})
            for _ in range(3):g.perform(g.priority,{'kind':'pass'})
            g.perform(3,{'kind':'cast','card':'Generous Gift','target_seat':0,'target_card':"Thassa's Oracle"})
        g.run_passes(1500)
    else:raise ValueError('unknown scenario')
    return g

if __name__=='__main__':
    names=('core_loop','crawler_finishes','crawler_counterplay','rift_interruption','oracle_wins','oracle_counterplay')
    data=[]
    for name in names:
        g=make_scenario(name)
        record={'scenario':name,**g.export(),'life':[p.life for p in g.players],
                'library_sizes':[len(p.library) for p in g.players]}
        record['trace_sha256']=hashlib.sha256(json.dumps(record['events'],sort_keys=True).encode()).hexdigest()
        data.append(record)
    out=HERE/'reports'/'bounded_combo_scenarios.json'
    out.write_text(json.dumps({'scope':'BOUNDED_SCENARIOS_NOT_GAMES','count':len(data),'scenarios':data},indent=2))
    print(json.dumps([{'scenario':x['scenario'],'outcome':x['outcome'],
                      'winner':x['winner'],'events':len(x['events']),
                      'drawn':x['stats'].get('successful_draws',0)} for x in data],indent=2))
