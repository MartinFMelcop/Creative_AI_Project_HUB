"""Summarize CURRENT four-deck experimental cohorts; no historical data is loaded."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
obj=json.loads((ROOT/'reports/current_kpis.json').read_text())
assert obj['oracle_rules_verified_complete_games']==0
assert len(obj['rules_sensitivity_mode1'])==2
print('Oracle-complete games: 0')
print('Final surrogate validation episodes:',obj['this_cycle_final_validation_games'])
for block in obj['rules_sensitivity_mode1']+obj['equipment_sensitivity_mode2']:
    assert sum(block['wins'])+block['unresolved_surrogate']==block['games']
    print(block['policy'],block['games'],block['win_rates_pct'],'max_gap_pp',block['max_abs_gap_pp'])
