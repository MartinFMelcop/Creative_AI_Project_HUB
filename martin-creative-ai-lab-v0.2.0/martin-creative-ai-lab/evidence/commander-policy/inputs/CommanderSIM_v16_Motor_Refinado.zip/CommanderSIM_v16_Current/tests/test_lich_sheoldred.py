import unittest,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'engine'))
from lich_sheoldred_bounded import resolve_bounded_draw_chain,oracle_endgame_ready
class MasterySheoldredSlice(unittest.TestCase):
 def test_draws_only_finite_remaining_library(self):
  r=resolve_bounded_draw_chain(deck_size=5,life=30)
  self.assertEqual(r.actual_cards_drawn,5)
  self.assertEqual(r.life_gained,10)
  self.assertTrue(r.emptied_library)
  self.assertTrue(r.cannot_lose_to_decking)
  self.assertGreater(r.failed_draw_attempts,0)
 def test_without_mastery_only_starting_draw(self):
  r=resolve_bounded_draw_chain(deck_size=20,mastery=False)
  self.assertEqual(r.actual_cards_drawn,1)
  self.assertEqual(r.life_gained,2)
 def test_without_sheoldred_no_chain(self):
  r=resolve_bounded_draw_chain(deck_size=20,sheoldred=False)
  self.assertEqual(r.actual_cards_drawn,1)
  self.assertEqual(r.life_gained,0)
 def test_crawler_can_convert_draws_into_opponent_elimination(self):
  r=resolve_bounded_draw_chain(deck_size=45,crawler=True)
  self.assertTrue(r.limited_card_win)
  self.assertTrue(all(h<=0 for h in r.opponents_remaining))
 def test_oracle_requires_actual_resolution_window(self):
  self.assertTrue(oracle_endgame_ready(library_remaining=0,oracle_in_hand=True,can_cast_sorcery=True,blue_mana=2,sheoldred_mastery_trigger_stack_empty=True))
  self.assertFalse(oracle_endgame_ready(library_remaining=0,oracle_in_hand=True,can_cast_sorcery=True,blue_mana=2,sheoldred_mastery_trigger_stack_empty=False))
 def test_invalid_arguments(self):
  with self.assertRaises(ValueError):resolve_bounded_draw_chain(deck_size=-1)
if __name__=='__main__':unittest.main()
