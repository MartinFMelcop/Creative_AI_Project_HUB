"""Bounded reference regressions; NOT complete rules-engine tests."""
import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1] / 'models'))
from palladia_rules_reference import CreatureObject, EquipmentReference, CommanderDamageLedger, nontargeted_destroy_affected

class PalladiaRulesTests(unittest.TestCase):
    def setUp(self): self.p=CreatureObject('Palladia-Mors, the Ruiner',1,100,6)
    def test_hexproof_before_first_damage(self):
        self.assertTrue(self.p.has_hexproof)
        self.assertFalse(self.p.legal_target_from(0))
        self.assertTrue(self.p.legal_target_from(1))
    def test_any_damage_can_end_hexproof_even_noncombat(self):
        self.p.deal_damage(1,combat=False)
        self.assertFalse(self.p.has_hexproof)
        self.assertTrue(self.p.legal_target_from(0))
    def test_zero_damage_does_not_end_hexproof(self):
        self.p.deal_damage(0,combat=True)
        self.assertTrue(self.p.has_hexproof)
    def test_blink_is_new_object(self):
        self.p.deal_damage(6,combat=True)
        p2=self.p.blinked(101)
        self.assertTrue(p2.has_hexproof)
        self.assertEqual(p2.damage_dealt_by_this_object,0)
    def test_nontargeted_destroy_ignores_hexproof(self):
        self.assertTrue(nontargeted_destroy_affected(self.p.has_hexproof))
    def test_equipment_cast_without_attachment_gives_no_bonus(self):
        e=EquipmentReference('Colossus Hammer');e.cast_to_battlefield()
        self.assertFalse(e.attached_bonus_applicable(self.p))
    def test_equip_requires_paid_cost_and_legal_timing(self):
        e=EquipmentReference('Blackblade Reforged');e.cast_to_battlefield()
        with self.assertRaises(ValueError):e.equip(self.p,cost_paid=False,sorcery_timing=True)
        with self.assertRaises(ValueError):e.equip(self.p,cost_paid=True,sorcery_timing=False)
        e.equip(self.p,cost_paid=True,sorcery_timing=True)
        self.assertTrue(e.attached_bonus_applicable(self.p))
        self.assertFalse(e.attached_bonus_applicable(self.p.blinked(105)))
    def test_commander_damage_not_all_combat_damage(self):
        l=CommanderDamageLedger()
        self.assertFalse(l.record(99,2,6,combat=True))
        self.assertFalse(l.record(99,2,6,combat=True))
        # 25 ordinary-creature damage never counts as commander damage.
        self.assertFalse(l.record(42,2,25,combat=False))
        self.assertEqual(l.combat_by_source_and_victim[(99,2)],12)
        self.assertTrue(l.record(99,2,9,combat=True))
    def test_commander_damage_kept_separate_by_victim(self):
        l=CommanderDamageLedger()
        self.assertFalse(l.record(99,2,12,combat=True))
        self.assertFalse(l.record(99,3,12,combat=True))
        self.assertFalse(l.record(88,2,12,combat=True))
        self.assertEqual(len(l.combat_by_source_and_victim),3)

if __name__=='__main__':unittest.main()
