"""End-to-end bounded legal-action/stack fixtures: zero complete MTG games."""
import sys,unittest,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'engine'))
from stack_combo_slice import ComboTable, IllegalAction, UnsupportedInteraction

class ComboPriorityTests(unittest.TestCase):
    def game(self,library=10,crawler=False):
        g=ComboTable(ROOT/'decks',seed=713,active_seat=0)
        for card in ["Sheoldred, the Apocalypse","Lich's Mastery"] + (["Psychosis Crawler"] if crawler else []):
            g.fixture_permanent(0,card)
        g.fixture_library_count(0,library)
        return g
    def test_four_seats_and_commanders_immutable(self):
        g=self.game();self.assertEqual(len(g.players),4)
        self.assertEqual(len(g.players[0].library),10)
        self.assertEqual(g.active_seat,0)
        self.assertEqual(g.outcome,'ONGOING')
    def test_sheoldred_mastery_draw_life_stack_chain_finite(self):
        g=self.game(library=5)
        g.start_fixture_draw(0)
        steps=g.run_passes(300)
        self.assertGreater(steps,0)
        self.assertEqual(g.stats['successful_draws'],5)
        self.assertEqual(g.stats['life_gained'],10)
        self.assertEqual(g.players[0].life,50)
        self.assertEqual(g.outcome,'ONGOING')
        self.assertFalse(g.players[0].drew_from_empty)  # SBA already checked
        self.assertGreater(g.stats['failed_draw_attempts'],0)
        self.assertTrue(any(x['type']=='loss_prevented_by_mastery' for x in g.log))
    def test_old_failed_draw_does_not_cause_later_loss_before_leave_trigger(self):
        g=self.game(library=1)
        g.start_fixture_draw();g.run_passes(200)
        self.assertEqual(g.outcome,'ONGOING')
        self.assertFalse(g.players[0].drew_from_empty)
        # Removing the enchantment creates its specific loss trigger;
        # no stale empty-deck state-based loss may fire here.
        g._remove(0,"Lich's Mastery",destination='hand')
        g._state_based()
        self.assertTrue(g.players[0].alive)
        g._flush_triggers();g.run_passes(30)
        self.assertFalse(g.players[0].alive)
        self.assertEqual(next(x['reason'] for x in g.log if x['type']=='player_lost'),
                         'mastery_leaves_battlefield_trigger')

    def test_crawler_ends_with_single_legitimate_winner_in_fixture(self):
        g=self.game(library=40,crawler=True)
        g.start_fixture_draw();g.run_passes(1000)
        self.assertEqual(g.outcome,'WIN');self.assertEqual(g.winner,0)
        self.assertEqual([p.alive for p in g.players],[True,False,False,False])
    def test_opponent_cannot_target_hexproof_mastery_with_gift(self):
        g=self.game()
        g.fixture_hand(3,'Generous Gift');g.fixture_mana(3,W=1,C=2)
        g.start_fixture_draw(0)
        # pass to seat3; ensure opponent may target Sheoldred but not Mastery.
        for _ in range(3):g.perform(g.priority,{'kind':'pass'})
        available=g.legal_actions(3)
        self.assertIn({'kind':'cast','card':'Generous Gift','target_seat':0,'target_card':'Sheoldred, the Apocalypse'}, available)
        self.assertNotIn({'kind':'cast','card':'Generous Gift','target_seat':0,'target_card':"Lich's Mastery"},available)
        with self.assertRaises(IllegalAction):g.perform(3,{'kind':'cast','card':'Generous Gift','target_seat':0,'target_card':"Lich's Mastery"})
    def test_overloaded_rift_bypasses_mastery_hexproof_and_loss_trigger(self):
        g=self.game(library=6)
        g.fixture_hand(2,'Cyclonic Rift');g.fixture_mana(2,U=1,C=6)
        g.start_fixture_draw(0)
        g.perform(0,{'kind':'pass'});g.perform(1,{'kind':'pass'})
        action={'kind':'cast','card':'Cyclonic Rift','mode':'overload'}
        self.assertIn(action,g.legal_actions(2))
        g.perform(2,action)
        g.run_passes(500)
        self.assertNotIn("Lich's Mastery",g.players[0].battlefield)
        self.assertFalse(g.players[0].alive)
        self.assertTrue(any(x['type']=='player_lost' and x['reason']=='mastery_leaves_battlefield_trigger' for x in g.log))
    def test_mana_exactly_three_black_mastery_and_not_two(self):
        g=ComboTable(ROOT/'decks',seed=2)
        g.fixture_hand(0,"Lich's Mastery")
        g.fixture_mana(0,B=2,C=4)
        card={'kind':'cast','card':"Lich's Mastery"}
        self.assertNotIn(card,g.legal_actions(0))
        g.fixture_mana(0,B=3,C=3)
        self.assertIn(card,g.legal_actions(0))
        g.perform(0,card);g.run_passes()
        self.assertIn("Lich's Mastery",g.players[0].battlefield)
        self.assertEqual(g.players[0].mana,{'B':0,'C':0})
    def test_oracle_etb_devotion_and_blue_mana(self):
        g=ComboTable(ROOT/'decks',seed=2)
        g.fixture_hand(0,"Thassa's Oracle")
        g.fixture_library_count(0,2);g.fixture_mana(0,U=2)
        g.perform(0,{'kind':'cast','card':"Thassa's Oracle"})
        g.run_passes(30)
        self.assertEqual(g.outcome,'WIN');self.assertEqual(g.winner,0)
        self.assertIn('oracle_win',[x['type'] for x in g.log])
    def test_oracle_cannot_win_if_devotion_smaller_than_library(self):
        g=ComboTable(ROOT/'decks',seed=2)
        g.fixture_hand(0,"Thassa's Oracle");g.fixture_library_count(0,3);g.fixture_mana(0,U=2)
        g.perform(0,{'kind':'cast','card':"Thassa's Oracle"});g.run_passes()
        self.assertEqual(g.outcome,'ONGOING')
    def test_oracle_removal_before_etb_resolution_reduces_devotion(self):
        g=ComboTable(ROOT/'decks',seed=2)
        g.fixture_hand(0,"Thassa's Oracle");g.fixture_library_count(0,2);g.fixture_mana(0,U=2)
        g.fixture_hand(3,'Generous Gift');g.fixture_mana(3,W=1,C=2)
        g.perform(0,{'kind':'cast','card':"Thassa's Oracle"})
        for _ in range(4):g.perform(g.priority,{'kind':'pass'})
        # Stack now contains oracle_etb; pass priority to seat 3.
        for _ in range(3):g.perform(g.priority,{'kind':'pass'})
        action={'kind':'cast','card':'Generous Gift','target_seat':0,'target_card':"Thassa's Oracle"}
        self.assertIn(action,g.legal_actions(3));g.perform(3,action);g.run_passes(40)
        self.assertEqual(g.outcome,'ONGOING')
        self.assertNotIn("Thassa's Oracle",g.players[0].battlefield)
    def test_eliminated_player_skipped_during_priority(self):
        g=self.game(library=2)
        g.fixture_life(1,1)
        g.start_fixture_draw(1)
        g.run_passes(50)
        self.assertFalse(g.players[1].alive)
        self.assertIn(g.priority,(0,2,3))
        self.assertEqual(g.outcome,'ONGOING')

    def test_observation_hidden_hands_and_deck(self):
        g=self.game()
        g.fixture_hand(2,'Cyclonic Rift');obs=g.observation(0)
        dump=json.dumps(obs)
        self.assertNotIn('Cyclonic Rift',dump)
        self.assertNotIn('library_order',dump)
    def test_targeted_crawler_removal_suppresses_future_draw_damage(self):
        g=self.game(library=40,crawler=True)
        g.fixture_hand(3,'Generous Gift');g.fixture_mana(3,W=1,C=2)
        g.start_fixture_draw()
        for _ in range(3):g.perform(g.priority,{'kind':'pass'})
        answer={'kind':'cast','card':'Generous Gift','target_seat':0,'target_card':'Psychosis Crawler'}
        self.assertIn(answer,g.legal_actions(3))
        g.perform(3,answer);g.run_passes(1500)
        self.assertEqual(g.outcome,'ONGOING')
        self.assertNotIn('Psychosis Crawler',g.players[0].battlefield)
        self.assertGreater(g.stats['successful_draws'],1)
        self.assertTrue(all(g.players[q].life>=39 for q in (1,2,3)))

    def test_mastery_can_be_exiled_by_its_own_life_loss_trigger(self):
        g=ComboTable(ROOT/'decks',seed=3)
        g.fixture_permanent(0,"Lich's Mastery")
        g._lose_life(0,1);g._flush_triggers();g.run_passes()
        self.assertFalse(g.players[0].alive)
        self.assertTrue(any(x['type']=='player_lost' and x['reason']=='mastery_leaves_battlefield_trigger' for x in g.log))

    def test_same_seed_event_trace_reproducible(self):
        def run():
            g=self.game(library=8,crawler=True)
            g.start_fixture_draw();g.run_passes(1000)
            return g.export()
        self.assertEqual(run(),run())
    def test_reject_unsupported_fixture_card(self):
        g=self.game()
        with self.assertRaises(UnsupportedInteraction):g.fixture_permanent(0,'Aetherflux Reservoir')
    def test_resource_limit_not_declared_a_draw(self):
        g=self.game(library=5);g.start_fixture_draw()
        with self.assertRaises(RuntimeError):g.run_passes(limit=1)
        self.assertEqual(g.outcome,'ONGOING')
    def test_sheoldred_opponent_draw_life_loss(self):
        g=self.game(library=5)
        g.fixture_library_count(1,5);g.start_fixture_draw(1);g.run_passes()
        self.assertEqual(g.players[1].life,38)
        self.assertEqual(g.players[0].life,40)
    def test_underlying_game_setup_does_not_draw_commanders(self):
        g=ComboTable(ROOT/'decks',seed=1)
        for i,cmds in enumerate((("Dralnu, Lich Lord",),("Palladia-Mors, the Ruiner",),
                                ("Be'lakor, the Dark Master",),("Livio, Oathsworn Sentinel","Ikra Shidiqi, the Usurper"))):
            for c in cmds:self.assertNotIn(c,g.players[i].library)
if __name__=='__main__':unittest.main()
