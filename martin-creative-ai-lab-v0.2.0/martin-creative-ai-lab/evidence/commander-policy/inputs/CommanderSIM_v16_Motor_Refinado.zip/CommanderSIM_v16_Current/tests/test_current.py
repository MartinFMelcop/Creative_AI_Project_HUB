"""Active-source-only CommanderSIM invariants, independent of any previous deck history."""
from pathlib import Path
from collections import Counter
import csv,json,hashlib,sys,unittest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'engine'))
from legal_priority_slice import BoundedGame,COMMANDERS
from equipment_bounded import PalladiaPermanent,Equipment,UnsupportedEquipment
N=['01_Dralnu','02_Palladia','03_Belakor','04_Abzan']
BASICS={'Plains','Island','Swamp','Mountain','Forest','Wastes','Snow-Covered Plains','Snow-Covered Island','Snow-Covered Swamp','Snow-Covered Mountain','Snow-Covered Forest','Snow-Covered Wastes'}

def parse(name):
 result=[]
 for l in (ROOT/'decks'/f'{name}.txt').read_text().splitlines():
  q,s=l.split(' ',1);result.extend([s]*int(q))
 return result

class CurrentSourceTest(unittest.TestCase):
 def test_exactly_four_active_decks(self):self.assertEqual(sorted(x.stem for x in (ROOT/'decks').glob('*.txt')),N)
 def test_counts_singletons_and_commanders(self):
  for seat,n in enumerate(N):
   cs=parse(n);ctr=Counter(cs)
   self.assertEqual(len(cs),100)
   self.assertFalse([(c,x) for c,x in ctr.items() if x>1 and c not in BASICS])
   self.assertEqual({c for c in ctr if c in sum([list(s) for s in COMMANDERS],[])},{*COMMANDERS[seat]})
 def test_profiles_match_current_txt_without_extra_cards(self):
  d={}
  for row in csv.DictReader((ROOT/'profiles.csv').read_text().splitlines(),delimiter='|'):
   key=(row['phase'],int(row['seat']))
   d.setdefault(key,[]).append(row)
  self.assertEqual(len(d),8)
  for phase in ['baseline','updated']:
   for seat,name in enumerate(N):
    rows=d[(phase,seat)]
    self.assertEqual([r['name'] for r in rows],parse(name))
    self.assertEqual([r['name'] for r in rows if r['commander']=='True'],[c for c in parse(name) if c in COMMANDERS[seat]])
 def test_manifest_file_hashes(self):
  m=json.loads((ROOT/'manifest.json').read_text())
  for i,n in enumerate(N):self.assertEqual(m['decks'][i]['sha256'],hashlib.sha256((ROOT/'decks'/f'{n}.txt').read_bytes()).hexdigest())
 def test_no_old_deck_containers_in_release(self):
  self.assertEqual(sorted(p.name for p in (ROOT/'decks').iterdir()),[n+'.txt' for n in N])
 def test_four_player_slice_starts_and_seat_identity(self):
  for starter in range(4):
   g=BoundedGame(ROOT/'decks',seed=42,starting_seat=starter)
   self.assertEqual(g.starter,starter)
   self.assertEqual([len(s.library) for s in g.seats],[99,99,99,98])
 def test_equipment_hammer_cannot_equip_without_eight_mana(self):
  p=PalladiaPermanent();e=Equipment('Colossus Hammer');e.cast_resolves()
  self.assertEqual(e.active_effect(p,5)['power_bonus'],0)
  self.assertEqual(e.legal_abilities(p,7,True,True),[])
  self.assertEqual(e.attach(p,paid=8,available=8,main_phase=True,stack_empty=True),0)
  self.assertEqual(e.active_effect(p,5),{'power_bonus':10,'removes_flying':True})
 def test_blackblade_legendary_discount(self):
  p=PalladiaPermanent();e=Equipment('Blackblade Reforged');e.cast_resolves()
  self.assertEqual(e.legal_abilities(p,3,True,True,True)[0]['cost_generic'],3)
  self.assertEqual(e.legal_abilities(p,3,True,True,False),[])
  e.attach(p,3,3,True,True,True)
  self.assertEqual(e.active_effect(p,6)['power_bonus'],6)
 def test_equipment_timing_and_blink(self):
  p=PalladiaPermanent();e=Equipment('Colossus Hammer');e.cast_resolves()
  self.assertEqual(e.legal_abilities(p,8,False,True),[])
  self.assertEqual(e.legal_abilities(p,8,True,False),[])
  e.attach(p,8,8,True,True)
  replacement=p.blink();e.detach_on_zone_change(p.uid)
  self.assertIsNone(e.attached_to)
  self.assertEqual(e.active_effect(replacement,9)['power_bonus'],0)
 def test_palladia_damage_and_hexproof(self):
  p=PalladiaPermanent()
  self.assertFalse(p.legal_target(0))
  p.receive_source_damage_event(1)
  self.assertTrue(p.legal_target(0))
  self.assertTrue(p.blink().hexproof())
 def test_unsupported_equipment_fails_closed(self):
  with self.assertRaises(UnsupportedEquipment):Equipment('Unknown Sword')
if __name__=='__main__':unittest.main()
