"""Exact bounded action tests; never claims that arbitrary Oracle cards are supported."""
import unittest,json,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'engine'))
from legal_priority_slice import BoundedGame,play_counterspell_fixture,IllegalAction,UnsupportedInteraction,COMMANDERS

class PrioritySliceTests(unittest.TestCase):
    def setUp(self):self.g=BoundedGame(ROOT/'decks',seed=123,starting_seat=0)
    def test_four_roster_and_commanders(self):
        self.assertEqual(len(self.g.seats),4)
        self.assertEqual([s.commanders for s in self.g.seats],list(COMMANDERS))
        self.assertEqual([len(s.library) for s in self.g.seats],[99,99,99,98])
    def test_no_fifth_seat(self):
        with self.assertRaises(ValueError):BoundedGame(ROOT/'decks',seed=1,starting_seat=4)
    def test_counterspell_requires_priority(self):
        self.g.fixture_spell_on_stack(2,"Be'lakor, the Dark Master")
        self.g.fixture_draw_specific(0,'Counterspell');self.g.fixture_mana(0,U=2)
        with self.assertRaises(IllegalAction):self.g.legal_actions(0)
        self.assertEqual(self.g.legal_actions(3),[{'kind':'pass','action_id':'pass'}])
    def test_counterspell_requires_blue_mana(self):
        self.g.fixture_spell_on_stack(2,"Be'lakor, the Dark Master")
        self.g.fixture_draw_specific(0,'Counterspell');self.g.fixture_mana(0,R=2)
        self.g.perform(3,{'kind':'pass','action_id':'pass'})
        self.assertEqual(len(self.g.legal_actions(0)),1)
    def test_counterspell_fully_resolves_to_command_zone(self):
        t=play_counterspell_fixture(ROOT/'decks')
        ev=[x['type'] for x in t['events']]
        self.assertIn('cast',ev);self.assertIn('countered',ev)
        self.assertIn('commander_sba_command',ev)
        self.assertEqual(t['chosen_action']['action_id'],'cast_counterspell')
        self.assertEqual([d['total_cards'] for d in t['decks']],[100]*4)
    def test_replay_bitwise(self):
        a=play_counterspell_fixture(ROOT/'decks',seed=999)
        b=play_counterspell_fixture(ROOT/'decks',seed=999)
        self.assertEqual(json.dumps(a,sort_keys=True),json.dumps(b,sort_keys=True))
    def test_no_hidden_opponent_hand_in_observation(self):
        self.g.fixture_spell_on_stack(2,"Be'lakor, the Dark Master")
        self.g.fixture_draw_specific(0,'Counterspell')
        self.assertNotIn('opponents_hands',str(self.g.observation(3)))
        self.assertNotIn('Counterspell',self.g.observation(3)['public_state'].__str__())
    def test_palladia_hexproof_blocks_opponent_target(self):
        pid=self.g.fixture_permanent(1,'Palladia-Mors, the Ruiner')
        self.g.fixture_draw_specific(0,'Go for the Throat');self.g.fixture_mana(0,B=1,C=1)
        self.assertEqual(len(self.g.legal_actions(0)),1)
        self.g.permanents[0].has_dealt_damage=True
        self.assertEqual(len(self.g.legal_actions(0)),2)
        self.assertEqual(self.g.legal_actions(0)[1]['target_pid'],pid)
    def test_remove_palladia_after_first_damage(self):
        self.g.fixture_permanent(1,'Palladia-Mors, the Ruiner',True)
        self.g.fixture_draw_specific(0,'Go for the Throat');self.g.fixture_mana(0,B=1,C=1)
        self.g.perform(0,self.g.legal_actions(0)[1])
        self.assertEqual(self.g.seats[0].mana['B'],0)
        for i in (0,1,2,3):self.g.perform(i,{'kind':'pass','action_id':'pass'})
        self.assertFalse(self.g.permanents)
        self.assertIn('Palladia-Mors, the Ruiner',self.g.seats[1].command)
    def test_cannot_invent_action(self):
        with self.assertRaises(IllegalAction):self.g.perform(0,{'kind':'interact','action_id':'exile_everything'})
    def test_unsupported_stack_card_fails_closed(self):
        with self.assertRaises(UnsupportedInteraction):self.g.fixture_spell_on_stack(0,'Memory Plunder')
    def test_unsupported_belakor_etb_fails_closed(self):
        self.g.fixture_spell_on_stack(2,"Be'lakor, the Dark Master")
        with self.assertRaises(UnsupportedInteraction):
            for seat in (3,0,1,2):self.g.perform(seat,{'kind':'pass','action_id':'pass'})
        self.assertEqual(self.g.events[-1]['type'],'unsupported_resolution')
