"""Current-only integration smoke tests; surrogate episodes are not Oracle MTG games."""
from pathlib import Path
import unittest,subprocess,os,json,tempfile,csv,hashlib
ROOT=Path(__file__).resolve().parents[1]

class ActiveRunContract(unittest.TestCase):
    def test_no_archives_or_branches_inside_active_decks(self):
        self.assertEqual(len(list((ROOT/'decks').glob('*.txt'))),4)
        self.assertFalse(any(x.is_dir() for x in (ROOT/'decks').iterdir()))
    def test_immutable_commander_and_card_coverage(self):
        commanders=[['Dralnu, Lich Lord'],['Palladia-Mors, the Ruiner'],["Be'lakor, the Dark Master"],['Livio, Oathsworn Sentinel','Ikra Shidiqi, the Usurper']]
        for i,p in enumerate(sorted((ROOT/'decks').glob('*.txt'))):
            cards=[]
            for line in p.read_text().splitlines():
                count,name=line.split(' ',1);cards.extend([name]*int(count))
            self.assertEqual(len(cards),100)
            self.assertEqual([c for c in cards if c in commanders[i]],commanders[i])
    def test_current_profile_exactly_matches_active_files(self):
        rows=list(csv.DictReader((ROOT/'profiles.csv').read_text().splitlines(),delimiter='|'))
        self.assertEqual(len(rows),800)
        for phase in ('baseline','updated'):
            for seat,path in enumerate(sorted((ROOT/'decks').glob('*.txt'))):
                source=[]
                for line in path.read_text().splitlines():
                    n,s=line.split(' ',1);source.extend([s]*int(n))
                self.assertEqual([x['name'] for x in rows if x['phase']==phase and int(x['seat'])==seat],source)
    def test_reproducible_full_abstract_smoke(self):
        exe=ROOT/'engine/simulate'
        if not exe.exists():self.skipTest('Compile C++ first')
        with tempfile.TemporaryDirectory() as td:
            env=dict(os.environ,COMMANDERSIM_FIXED_POLICY='1',COMMANDERSIM_AUDIT_MODE='1')
            outputs=[]
            for i in range(2):
                out=Path(td)/f'run{i}.json'
                result=subprocess.run([str(exe),str(ROOT),'8','-1','25000000',str(out)],env=env,capture_output=True,text=True)
                self.assertEqual(result.returncode,0,result.stderr)
                obj=json.loads(out.read_text());self.assertEqual(obj['metadata']['total_four_player_games'],16)
                self.assertEqual([x['games'] for x in obj['phases']],[8,8])
                self.assertEqual(obj['phases'][0]['wins'],obj['phases'][1]['wins'])
                outputs.append(hashlib.sha256(out.read_bytes()).hexdigest())
            self.assertEqual(*outputs)
if __name__=='__main__':unittest.main()
