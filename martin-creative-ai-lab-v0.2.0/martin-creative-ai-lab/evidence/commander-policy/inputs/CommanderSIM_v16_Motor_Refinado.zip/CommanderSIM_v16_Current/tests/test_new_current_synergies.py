import unittest,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]
class NewCurrentSynergies(unittest.TestCase):
 def test_combined_dralnu_synergy_cards_present(self):
  names=[f.read_text() for f in sorted((R/'decks').glob('*.txt'))]
  for card in ["Lich's Mastery",'Sheoldred, the Apocalypse',"Thassa's Oracle",'Psychosis Crawler','Demonic Tutor','Vampiric Tutor','Professor Onyx','Aetherflux Reservoir']:
   self.assertIn('1 '+card+'\n',names[0]);self.assertEqual(names[0].count('1 '+card+'\n'),1)
  self.assertIn('Forge Anew',names[1]);self.assertIn('Thassa, Deep-Dwelling',names[2])
 def test_immutable_four_decks(self):
  m=json.loads((R/'manifest.json').read_text());self.assertEqual(len(m['decks']),4)
  for d in m['decks']:
   self.assertEqual(d['card_count'],100)
   self.assertEqual(hashlib.sha256((R/'decks'/d['file']).read_bytes()).hexdigest(),d['sha256'])
 def test_no_claim_full_oracle_games(self):
  self.assertEqual(json.loads((R/'manifest.json').read_text())['oracle_complete_games'],0)
