"""Create executable bounded scenario traces from current active four-deck source."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/"engine"))
from legal_priority_slice import BoundedGame,play_counterspell_fixture
import json
R=Path(__file__).resolve().parent
trace=play_counterspell_fixture(R/'decks',seed=7331)
g=BoundedGame(R/'decks',seed=7332,starting_seat=0)
g.fixture_permanent(1,'Palladia-Mors, the Ruiner',has_dealt_damage=False)
g.fixture_draw_specific(0,'Go for the Throat');g.fixture_mana(0,B=1,C=1)
before=g.legal_actions(0)
g.permanents[0].has_dealt_damage=True
after=g.legal_actions(0)
obj={'engine':'VERIFIED_BOUNDED_SCENARIOS_NOT_COMPLETE_GAMES','scenario_count':2,'counterspell_belakor':trace,'palladia_protection':{'legal_before_first_damage':before,'legal_after_damage':after,'note':'Uses fixture state, not natural whole-game progression'}}
(R/'reports/bounded_scenario_traces.json').write_text(json.dumps(obj,indent=2,ensure_ascii=False))
print('Bounded scenarios: 2')
