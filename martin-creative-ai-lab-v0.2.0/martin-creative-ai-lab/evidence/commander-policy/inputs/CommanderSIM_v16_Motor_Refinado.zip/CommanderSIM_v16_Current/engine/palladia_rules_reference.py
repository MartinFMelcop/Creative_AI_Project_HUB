"""Small bounded rule reference (NOT a complete Magic rules engine).

Source notes: Wizards of the Coast Core Set 2019 release notes; Commander format;
Comprehensive Rules 301.5 / 702.6 (equipment), 903.10a (commander combat damage).
No automatic legal-action generation is implemented here.
"""
from dataclasses import dataclass, field

@dataclass
class CreatureObject:
    oracle_name: str
    controller: int
    battlefield_id: int
    base_power: int
    damage_dealt_by_this_object: int = 0

    @property
    def has_hexproof(self):
        if self.oracle_name != 'Palladia-Mors, the Ruiner':
            return False
        return self.damage_dealt_by_this_object == 0

    def legal_target_from(self, caster_seat: int):
        return not (self.has_hexproof and caster_seat != self.controller)

    def deal_damage(self, amount: int, *, combat: bool):
        if amount < 0:
            raise ValueError('Negative damage')
        self.damage_dealt_by_this_object += amount
        return {'source': self.battlefield_id, 'amount': amount, 'combat': combat}

    def blinked(self, new_id: int):
        if new_id == self.battlefield_id:
            raise ValueError('Zone change must produce new object identity')
        return CreatureObject(self.oracle_name, self.controller, new_id, self.base_power)

@dataclass
class EquipmentReference:
    name: str
    attached_to: int | None = None
    on_battlefield: bool = False
    attach_cost_paid: bool = False
    def cast_to_battlefield(self):
        self.on_battlefield = True
        self.attached_to = None
        self.attach_cost_paid = False
    def equip(self, creature: CreatureObject, *, cost_paid: bool, sorcery_timing: bool):
        if not self.on_battlefield or not cost_paid or not sorcery_timing:
            raise ValueError('Generic equip requires battlefield, paid cost, sorcery timing')
        self.attached_to = creature.battlefield_id
        self.attach_cost_paid = True
    def attached_bonus_applicable(self, creature: CreatureObject):
        return self.on_battlefield and self.attached_to == creature.battlefield_id

@dataclass
class CommanderDamageLedger:
    combat_by_source_and_victim: dict[tuple[int,int], int] = field(default_factory=dict)
    def record(self, commander_card_identity: int, defending_player: int, amount: int, *, combat: bool):
        if amount < 0:
            raise ValueError('Negative damage')
        if combat:
            key = (commander_card_identity, defending_player)
            self.combat_by_source_and_victim[key] = self.combat_by_source_and_victim.get(key,0)+amount
        return self.combat_by_source_and_victim.get((commander_card_identity,defending_player),0) >= 21

def nontargeted_destroy_affected(has_hexproof: bool) -> bool:
    """Hexproof alone doesn't prevent a nontargeted destroy-all-creatures effect."""
    return True
