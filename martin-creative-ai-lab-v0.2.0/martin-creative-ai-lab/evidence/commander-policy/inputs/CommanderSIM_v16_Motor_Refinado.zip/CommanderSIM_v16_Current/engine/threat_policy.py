"""Frozen historical priors + externally supplied LEGAL actions only.
This is a research policy adapter; it cannot certify legal Magic actions itself.
No hidden information may pass through observations or feature maps.
"""
from __future__ import annotations
import json, math, hashlib
from dataclasses import dataclass
from pathlib import Path

FORBIDDEN={'opponents_hands','opponent_hand','unknown_library_order','library_order',
           'hidden_deck_contents','private_opponent_zone','opponent_private',
           'future_draws','future_outcomes','winner_future','hand','hands','hand_cards'}

class PrivacyViolation(ValueError): pass
class NoVerifiedActions(ValueError): pass

def validate_public_tree(obj):
    if isinstance(obj,dict):
        for k,v in obj.items():
            if str(k).lower() in FORBIDDEN:
                raise PrivacyViolation('hidden feature in observation: '+str(k))
            validate_public_tree(v)
    elif isinstance(obj,(tuple,list)):
        for v in obj:validate_public_tree(v)

@dataclass(frozen=True)
class PolicyInput:
    seat:int
    own_hand:tuple[str,...]
    public_state:dict
    legal_actions:tuple[dict,...]
    rules_engine_verified:bool

    def __post_init__(self):
        if self.seat not in range(4):raise ValueError('exact four player seats required')
        validate_public_tree(self.public_state)
        validate_public_tree(self.legal_actions)
        if not self.rules_engine_verified or not self.legal_actions:
            raise NoVerifiedActions('Cannot choose MTG legal moves without verified action source')

class ContextualThreatPolicy:
    """Scores only actions supplied by a verified rules engine, never creates actions.
    Win probabilities and salt must not be inferred from ordinal observational scores.
    """
    def __init__(self, frozen_priors:dict, version:str):
        self.priors=dict(frozen_priors)
        self.version=version
        self.snapshot_hash=hashlib.sha256(json.dumps(sorted([(seat,name,value) for (seat,name),value in self.priors.items()]),sort_keys=True).encode()).hexdigest()

    def action_utility(self, inp:PolicyInput, action:dict)->float:
        kind=action.get('kind')
        own_role=action.get('response_role','')
        target=action.get('target_card','')
        owner=int(action.get('target_seat',-1))
        if owner>=4 or owner< -1:raise ValueError('Bad owner')
        if not (isinstance(target,str) and isinstance(kind,str)):raise ValueError('bad action schema')
        # Default = conservative, preserving resources; no unconditional removal.
        if kind=='pass':return 0.0
        if kind=='interact':
            base=float(self.priors.get((owner,target),2.5))
            urgency=float(action.get('public_immediate_win_risk',0.0))
            synergy=float(action.get('public_synergy_risk',0.0))
            cost=float(action.get('resource_opportunity_cost',0.0))
            consequence=float(action.get('political_retaliation_cost',0.0))
            own_danger=float(inp.public_state.get('public_own_danger',0.0))
            features=(base,urgency,synergy,cost,consequence,own_danger)
            if not all(math.isfinite(x) for x in features):raise ValueError('nonfinite public features')
            return base*.38+urgency*2.5+synergy*.5+own_danger*.4-cost-consequence-1.5
        if kind=='develop':
            value=float(action.get('public_expected_resource_gain',0))
            cost=float(action.get('resource_opportunity_cost',0))
            if not(math.isfinite(value) and math.isfinite(cost)):raise ValueError('nonfinite feature')
            return value-cost
        raise ValueError('unknown action kind; fail closed')

    def choose(self,inp:PolicyInput)->dict:
        scored=[self.action_utility(inp,a) for a in inp.legal_actions]
        return inp.legal_actions[max(range(len(scored)),key=lambda i:(scored[i],-i))]

    @classmethod
    def from_frozen_snapshot(cls,path:Path):
        snap=json.loads(path.read_text())
        if snap.get('valid_magic_rules') is not False or snap.get('usage','').find('FROZEN')<0:
            raise ValueError('snapshot provenance invalid')
        priors={(c['seat']-1,c['name']):float(c['prior']) for c in snap['cards']}
        return cls(priors,version='research-threat-policy-v07')
