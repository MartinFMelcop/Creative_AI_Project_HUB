"""Bounded, source-attributed Palladia equipment test cases; not an Oracle engine.
Fixture cards: Colossus Hammer, Blackblade Reforged. Other equipment fail closed.
Sources: Core Set 2019 release notes, published card rules texts (see README).
"""
from dataclasses import dataclass,field

class UnsupportedEquipment(ValueError):pass

EQUIP_COSTS={"Colossus Hammer":(8,8),"Blackblade Reforged":(7,3)}

@dataclass
class PalladiaPermanent:
    uid:int=1
    controller:int=1
    power:int=6
    flying:bool=True
    dealt_damage:int=0
    def hexproof(self):return self.dealt_damage==0
    def legal_target(self,opponent):return not (opponent!=self.controller and self.hexproof())
    def receive_source_damage_event(self,amount):
        if amount<0:raise ValueError('Invalid negative damage')
        self.dealt_damage+=amount
    def blink(self):return PalladiaPermanent(self.uid+1,self.controller)

@dataclass
class Equipment:
    name:str
    uid:int=10
    battlefield:bool=False
    attached_to:int|None=None
    def __post_init__(self):
        if self.name not in EQUIP_COSTS:raise UnsupportedEquipment(self.name)
    def cast_resolves(self):self.battlefield=True;self.attached_to=None
    def legal_abilities(self,creature:PalladiaPermanent,mana:int,main_phase:bool,stack_empty:bool,legendary:bool=True):
        if not self.battlefield or not main_phase or not stack_empty or creature.controller!=1:return []
        cost=EQUIP_COSTS[self.name][1 if legendary else 0]
        return [{'equipment':self.name,'cost_generic':cost,'target_uid':creature.uid}] if mana>=cost else []
    def attach(self,creature,paid:int,available:int,main_phase:bool,stack_empty:bool,legendary:bool=True):
        options=self.legal_abilities(creature,available,main_phase,stack_empty,legendary)
        if not options or options[0]['cost_generic']!=paid:raise ValueError('Illegal equip activation')
        self.attached_to=creature.uid
        return available-paid
    def active_effect(self,creature:PalladiaPermanent,land_count:int):
        if self.attached_to!=creature.uid:return {'power_bonus':0,'removes_flying':False}
        if self.name=='Colossus Hammer':return {'power_bonus':10,'removes_flying':True}
        if self.name=='Blackblade Reforged':return {'power_bonus':land_count,'removes_flying':False}
        raise UnsupportedEquipment(self.name)
    def detach_on_zone_change(self,former_uid:int):
        if self.attached_to==former_uid:self.attached_to=None
