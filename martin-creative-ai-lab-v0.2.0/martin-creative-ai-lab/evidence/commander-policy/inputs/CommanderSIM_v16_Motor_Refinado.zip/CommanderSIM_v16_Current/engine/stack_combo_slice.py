"""Four-seat, deterministic, narrow card-interaction engine.

Supported cards/abilities: Sheoldred (own/opposing draw triggers), Lich's
Mastery (gain/draw, no-loss, leave trigger, simplified exile choice), Psychosis
Crawler (own draw), Thassa's Oracle (UU/ETB devotion at resolution), Generous
Gift (2W targeting eligible permanent), overloaded Cyclonic Rift (6U, nonland
permanents opponents control). Only explicit fixture states, NEVER full games.

Supported trigger-stack APNAP ordering for effects modeled here, four priority
passes, colored/generic mana payment, and independent seat observations.
All other Oracle abilities must fail closed. See reports/rules_coverage.json.
"""
from dataclasses import dataclass, field, asdict
from collections import Counter
import random, json
from pathlib import Path
from legal_priority_slice import COMMANDERS, NAMES, read_counts, IllegalAction, UnsupportedInteraction

BLUE_DEVOTION = {"Thassa's Oracle": 2, "Psychosis Crawler": 0,
                 "Sheoldred, the Apocalypse": 0, "Lich's Mastery": 0}
SUPPORTED_PERMANENTS = {"Thassa's Oracle", "Psychosis Crawler",
                        "Sheoldred, the Apocalypse", "Lich's Mastery"}
SUPPORTED_SPELLS = {"Thassa's Oracle", "Generous Gift", "Cyclonic Rift",
                    "Lich's Mastery", "Sheoldred, the Apocalypse", "Psychosis Crawler"}

@dataclass
class Effect:
    kind: str
    controller: int
    source: str
    n: int=0
    target: int|None=None

@dataclass
class Player:
    life: int=40
    library: list[str]=field(default_factory=list)
    hand: list[str]=field(default_factory=list)
    graveyard: list[str]=field(default_factory=list)
    battlefield: list[str]=field(default_factory=list)
    mana: dict[str,int]=field(default_factory=dict)
    alive: bool=True
    drew_from_empty: bool=False  # Since the most recent state-based-action check only

class ComboTable:
    """No turn progression; each fixture is a controlled priority-window experiment."""
    def __init__(self, deck_folder:Path, seed:int=1, active_seat:int=0):
        if active_seat not in range(4):raise ValueError('Four seats required')
        self.rng=random.Random(seed);self.seed=seed;self.active_seat=active_seat
        self.players=[];self.stack=[];self.pending=[];self.log=[]
        self.priority=active_seat;self.pass_count=0;self.winner=None;self.outcome='ONGOING';self.seq=0
        self.stats=Counter();self.fixture_used=False
        for seat,stem in enumerate(NAMES):
            counts=read_counts(Path(deck_folder)/(stem+'.txt'))
            if sum(counts.values())!=100:raise ValueError('Each Commander list requires 100 cards')
            if any(counts[c]!=1 for c in COMMANDERS[seat]):raise ValueError('Commander mismatch')
            for c in COMMANDERS[seat]:counts[c]-=1
            non_commanders=[card for card,n in counts.items() for _ in range(n)]
            self.rng.shuffle(non_commanders)
            self.players.append(Player(library=non_commanders))
    def _emit(self,event_type,**detail):
        self.seq+=1;self.log.append({'seq':self.seq,'type':event_type,**detail})
    def fixture_permanent(self,seat:int,card:str):
        self._ensure_fixture();p=self.players[seat]
        if card not in SUPPORTED_PERMANENTS:raise UnsupportedInteraction(card)
        p.library.remove(card);p.battlefield.append(card)
        self._emit('fixture_permanent',seat=seat,card=card)
    def fixture_hand(self,seat:int,card:str):
        self._ensure_fixture()
        if card not in SUPPORTED_SPELLS:raise UnsupportedInteraction(card)
        p=self.players[seat];p.library.remove(card);p.hand.append(card)
        self._emit('fixture_hand',seat=seat,card=card)
    def fixture_mana(self,seat:int,**pool):
        self._ensure_fixture()
        if any(k not in 'WUBRGC' or type(v)!=int or v<0 for k,v in pool.items()):raise ValueError('invalid pool')
        self.players[seat].mana=dict(pool)
    def fixture_library_count(self,seat:int,count:int):
        """Remove unmodeled cards to make a bounded endgame. This is NOT a game action."""
        self._ensure_fixture()
        p=self.players[seat]
        if not 0<=count<=len(p.library):raise ValueError('invalid fixture library size')
        p.library=p.library[:count];self._emit('fixture_library_size',seat=seat,count=count)
    def fixture_life(self,seat:int,life:int):
        self._ensure_fixture();self.players[seat].life=life
    def _ensure_fixture(self):
        if self.seq>0 and not self.fixture_used:pass
        if self.outcome!='ONGOING' or self.stack or self.pending:raise IllegalAction('fixture requires idle setup')
        self.fixture_used=True
    def _controlled(self,seat:int,card:str):return card in self.players[seat].battlefield
    def _add_trigger(self,kind,controller,source,n=0,target=None):
        self.pending.append(Effect(kind,controller,source,n,target))
    def _next_alive(self,seat:int):
        for k in range(1,5):
            q=(seat+k)%4
            if self.players[q].alive:return q
        return seat
    def _flush_triggers(self):
        if self.outcome!='ONGOING':
            self.pending.clear();return
        # APNAP: active-player triggers below nonactive-player triggers. Within a
        # controller, chosen sequence is deterministic (fixture policy).
        for seat in [(self.active_seat+i)%4 for i in range(4)]:
            same=[x for x in self.pending if x.controller==seat]
            for effect in same:
                self.stack.append(effect)
                self._emit('trigger_stack',seat=seat,kind=effect.kind,source=effect.source)
        self.pending.clear()
    def _draw(self,seat:int,n:int):
        for _ in range(n):
            p=self.players[seat]
            if not p.alive:break
            if not p.library:
                p.drew_from_empty=True;self.stats['failed_draw_attempts']+=1
                self._emit('draw_failed_empty',seat=seat)
            else:
                card=p.library.pop();p.hand.append(card);self.stats['successful_draws']+=1
                self._emit('draw',seat=seat,private_card_hidden=True)
                if self._controlled(seat,"Psychosis Crawler"):
                    self._add_trigger('crawler',seat,'Psychosis Crawler')
                for controller in range(4):
                    if self._controlled(controller,'Sheoldred, the Apocalypse'):
                        self._add_trigger('sheoldred_gain' if controller==seat else 'sheoldred_drain',
                                          controller,'Sheoldred, the Apocalypse',2,seat)
        self._state_based()
    def start_fixture_draw(self,seat:int=0):
        if self.stack or self.pending or self.outcome!='ONGOING':raise IllegalAction('Not idle')
        if not self.players[seat].alive:raise IllegalAction('Eliminated player cannot draw')
        self._draw(seat,1);self._flush_triggers();self.pass_count=0
        self.priority=self.active_seat if self.players[self.active_seat].alive else self._next_alive(self.active_seat)
    def _lose(self,seat:int,reason:str):
        if not self.players[seat].alive:return
        # Can't lose effect is static, only while Lich's Mastery remains.
        if self._controlled(seat,"Lich's Mastery"):
            self._emit('loss_prevented_by_mastery',seat=seat,reason=reason);return
        self.players[seat].alive=False;self._emit('player_lost',seat=seat,reason=reason)
        self._check_winner()
    def _check_winner(self):
        alive=[i for i,p in enumerate(self.players) if p.alive]
        if len(alive)==1:self.outcome='WIN';self.winner=alive[0]
        elif not alive:self.outcome='DRAW_ALL_LOSE'
    def _state_based(self):
        for i,p in enumerate(self.players):
            if p.alive and p.life<=0:self._lose(i,'life_total')
            if p.alive and p.drew_from_empty:self._lose(i,'empty_library_draw')
            p.drew_from_empty=False
    def _gain(self,seat:int,n:int):
        self.players[seat].life+=n;self.stats['life_gained']+=n
        self._emit('gain_life',seat=seat,amount=n)
        if self._controlled(seat,"Lich's Mastery"):
            self._add_trigger('mastery_draw',seat,"Lich's Mastery",n)
    def _lose_life(self,seat:int,n:int):
        self.players[seat].life-=n;self._emit('lose_life',seat=seat,amount=n)
        if self._controlled(seat,"Lich's Mastery"):
            self._add_trigger('mastery_exile',seat,"Lich's Mastery",n)
        self._state_based()
    def _remove(self,seat:int,card:str,destination='graveyard'):
        p=self.players[seat]
        if card not in p.battlefield:return False
        p.battlefield.remove(card)
        if destination=='graveyard':p.graveyard.append(card)
        elif destination=='hand':p.hand.append(card)
        elif destination!='exile':raise ValueError('bad destination')
        self._emit('permanent_left',seat=seat,card=card,zone=destination)
        if card=="Lich's Mastery":self._add_trigger('mastery_leave',seat,card)
        return True
    @staticmethod
    def _payment(pool,colored,generic):
        paid=Counter(colored)
        remaining=dict(pool)
        for c,n in paid.items():
            if remaining.get(c,0)<n:return None
            remaining[c]-=n
        for c in 'CWUBRG':
            take=min(generic,remaining.get(c,0))
            if take:
                remaining[c]-=take;paid[c]+=take;generic-=take
        return dict(paid) if generic==0 else None
    def legal_actions(self,seat:int):
        if seat!=self.priority or self.outcome!='ONGOING':return []
        actions=[{'kind':'pass'}];p=self.players[seat]
        if not p.alive:return actions
        if seat==self.active_seat and not self.stack:
            for card,colored,generic in (("Thassa's Oracle",{'U':2},0),
                                         ("Lich's Mastery",{'B':3},3),
                                         ("Sheoldred, the Apocalypse",{'B':2},2),
                                         ("Psychosis Crawler",{},5)):
                if card in p.hand and self._payment(p.mana,colored,generic) is not None:
                    actions.append({'kind':'cast','card':card})
        if "Cyclonic Rift" in p.hand and self._payment(p.mana,{'U':1},6) is not None:
            actions.append({'kind':'cast','card':'Cyclonic Rift','mode':'overload'})
        if 'Generous Gift' in p.hand and self._payment(p.mana,{'W':1},2) is not None:
            for q,other in enumerate(self.players):
                for card in other.battlefield:
                    if q!=seat and card=="Lich's Mastery":continue  # hexproof
                    actions.append({'kind':'cast','card':'Generous Gift','target_seat':q,'target_card':card})
        return actions
    def observation(self,seat:int):
        # No opponent hand, library order or private events.
        return {'seat':seat,'own_hand':list(self.players[seat].hand),
                'own_library_count':len(self.players[seat].library),
                'public':{'life':[p.life for p in self.players],
                          'battlefield':[list(p.battlefield) for p in self.players],
                          'library_sizes':[len(p.library) for p in self.players],
                          'stack':[{'kind':e.kind,'controller':e.controller,'source':e.source} for e in self.stack],
                          'priority':self.priority},'legal_actions':self.legal_actions(seat)}
    def perform(self,seat:int,action:dict):
        if action not in self.legal_actions(seat):raise IllegalAction('Not in bounded legal-action set')
        if action['kind']=='pass':
            self.stats['passes']+=1;self.pass_count+=1
            self._emit('pass',seat=seat)
            if self.pass_count==sum(p.alive for p in self.players):
                self.pass_count=0
                if self.stack:
                    effect=self.stack.pop();self._resolve(effect)
                    self._flush_triggers();self._state_based()
                    self._emit('resolved',effect=effect.kind)
                self.priority=self.active_seat if self.players[self.active_seat].alive else self._next_alive(self.active_seat)
            else:self.priority=self._next_alive(seat)
            return
        card=action['card'];pool=self.players[seat].mana
        costs={"Thassa's Oracle":({'U':2},0),"Lich's Mastery":({'B':3},3),
               'Sheoldred, the Apocalypse':({'B':2},2),
               'Psychosis Crawler':({},5),
               'Cyclonic Rift':({'U':1},6),'Generous Gift':({'W':1},2)}
        colored,generic=costs[card]
        paid=self._payment(pool,colored,generic)
        if paid is None:raise IllegalAction('Insufficient colored/generic mana')
        for color,n in paid.items():
            if n:pool[color]-=n
        self.players[seat].hand.remove(card)
        self.stack.append(Effect('spell',seat,card,target=action.get('target_seat'),
                                 n=0))
        if card=='Generous Gift':self.stack[-1].target_card=action['target_card']
        self._emit('cast',seat=seat,card=card,spent=paid,mode=action.get('mode'))
        self.pass_count=0;self.priority=seat
    def _resolve(self,e:Effect):
        if e.kind=='spell':
            if e.source in SUPPORTED_PERMANENTS:
                self.players[e.controller].battlefield.append(e.source)
                if e.source=="Thassa's Oracle":
                    self._add_trigger('oracle_etb',e.controller,e.source)
            elif e.source=='Cyclonic Rift':
                for seat,p in enumerate(self.players):
                    if seat!=e.controller:
                        for card in p.battlefield[:]:self._remove(seat,card,'hand')
            elif e.source=='Generous Gift':
                illegal_hexproof=(e.target!=e.controller and e.target_card=="Lich's Mastery")
                if not illegal_hexproof and self._remove(e.target,e.target_card):
                    self.players[e.target].battlefield.append('Elephant Token')
                else:self._emit('target_illegal_on_resolution',card=e.target_card)
            else:raise UnsupportedInteraction(e.source)
            if e.source not in SUPPORTED_PERMANENTS:
                self.players[e.controller].graveyard.append(e.source)
        elif e.kind=='sheoldred_gain':self._gain(e.controller,2)
        elif e.kind=='sheoldred_drain':self._lose_life(e.target,2)
        elif e.kind=='crawler':
            for q,p in enumerate(self.players):
                if q!=e.controller and p.alive:self._lose_life(q,1)
        elif e.kind=='mastery_draw':self._draw(e.controller,e.n)
        elif e.kind=='mastery_leave':self._lose(e.controller,'mastery_leaves_battlefield_trigger')
        elif e.kind=='mastery_exile':
            # Fixture deterministic exile ordering; NOT a general MTG choice engine.
            p=self.players[e.controller]
            for _ in range(e.n):
                if p.hand:p.hand.pop();self._emit('mastery_exile_hand',seat=e.controller)
                elif p.graveyard:p.graveyard.pop();self._emit('mastery_exile_graveyard',seat=e.controller)
                elif p.battlefield:self._remove(e.controller,p.battlefield[-1],destination='exile')
                else:break
        elif e.kind=='oracle_etb':
            controller=e.controller;p=self.players[controller]
            devotion=sum(BLUE_DEVOTION.get(c,0) for c in p.battlefield)
            if devotion>=len(p.library):
                self.outcome='WIN';self.winner=controller;self._emit('oracle_win',seat=controller,devotion=devotion,library=len(p.library))
            else:self._emit('oracle_no_win',seat=controller,devotion=devotion,library=len(p.library))
        else:raise UnsupportedInteraction(e.kind)
    def run_passes(self,limit:int=2000):
        """Drive PASS-only fixture to idle. Limit is diagnostic, not a game turn cap."""
        steps=0
        while self.stack and self.outcome=='ONGOING':
            if steps>=limit:raise RuntimeError('BOUNDED_FIXTURE_RESOURCE_LIMIT; game outcome unresolved')
            self.perform(self.priority,{'kind':'pass'});steps+=1
        return steps
    def export(self):
        return {'label':'BOUNDED_RULE_SLICE_NOT_COMPLETE_MAGIC',
                'seed':self.seed,'outcome':self.outcome,'winner':self.winner,
                'stats':dict(self.stats),'events':self.log}
