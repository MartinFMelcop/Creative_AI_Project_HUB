// CommanderSIM v0.7 frozen-prior experimental strategic SURROGATE. NOT a Comprehensive Rules MTG engine.
// No turn cap; true Magic draws cannot be asserted by this approximate model.
// Copyright (c) 2026. Statistical modeling research code; no Oracle card text shipped.
#include <bits/stdc++.h>
using namespace std;
static int AUDIT_MODE=1; // 0 legacy; 1 source+double; 2 equip; 3 threat stress; 4 source-only; 5 double-count-only
static int FIXED_POLICY_MODE = -1; // Override historical phase-policy confound when comparing two decklists.
struct RNG {
 uint64_t s;
 explicit RNG(uint64_t v):s(v? v:0x9e3779b97f4a7c15ULL){}
 inline uint32_t u32(){s^=s>>12; s^=s<<25; s^=s>>27; return uint32_t((s*2685821657736338717ULL)>>32);}
 inline int ir(int n){return n?int(uint64_t(u32())*n >> 32):0;}
 inline double uni(){return u32()*(1./4294967296.);}
};
struct Card {int seat,id,mana,land,cmd,role; string name; double prior=2.5;};
enum Role{LAND,RAMP,DRAW,COUNTER,REMOVE,WIPE,PROTECT,EQUIP,ENGINE,BLINK,REANIMATE,THREAT,FINISH};
int to_role(string x){
 if(x=="land")return LAND;if(x=="ramp")return RAMP;if(x=="draw")return DRAW;
 if(x=="counter")return COUNTER;if(x=="remove")return REMOVE;if(x=="boardwipe")return WIPE;
 if(x=="protect")return PROTECT;if(x=="equipment")return EQUIP;if(x=="engine")return ENGINE;
 if(x=="blink")return BLINK;if(x=="reanimate")return REANIMATE;if(x=="finisher")return FINISH;
 if(x=="threat")return THREAT;
 throw invalid_argument("UNKNOWN_CARD_ROLE: "+x);
}
const char* role_name(int r){static const char* roles[]={"land","ramp","draw","counter","remove","boardwipe","protect","equipment","engine","blink","reanimate","threat","finisher"};return r>=0 && r<13?roles[r]:"UNRECOGNIZED";}
vector<string> split(string s,char c){vector<string> r;string x;stringstream ss(s);while(getline(ss,x,c))r.push_back(x);return r;}
struct Stat {uint64_t drawn=0,played=0,win_played=0,eligible_response_windows=0,interventions=0;long double utility=0,denied_value_proxy=0;};
struct Agg {uint64_t win[4]={},draw=0,total=0,ended=0;double turns=0;uint64_t start_counts[4]={};uint64_t round_hist[129]={};uint64_t played_events=0;uint64_t attacks_received[4]={}, removal_targeted[4]={}, commander_damage_eliminations[4]={}, equipment_attaches[4]={}; double commander_damage_estimated[4]={};Stat stat[4][100];};
struct State {
 double life=40,board=0,def=0,resource=0,eng=0,extraDraw=0,gear=0,shield=0;
 int lands=0,counter=0,mana=0,resent[4]={},cmd_casts[2]={},cmd_active[2]={};
 double cmd_dmg[4][2]={};double spellslinger=0,sneak=0,gear_waiting=0;int library[99]={},libn=0,drawpos=0,hand[100]={},handn=0;
 bool active=true,used[100]={};
};
static inline double clampd(double x,double a,double b){return min(b,max(a,x));}
struct GameResult {int winner=-1,rounds=0;};
GameResult play(const vector<Card> cards[2][4],int phase,uint64_t seed,Agg &agg,ostream* trace=nullptr){
 vector<array<double,13>> episode;
 const int policy_mode = FIXED_POLICY_MODE >= 0 ? FIXED_POLICY_MODE : phase;
 RNG rng(seed);State P[4];int starting=rng.ir(4); agg.start_counts[starting]++; // No predetermined turn termination. Approximate exhaustion of a finite surrogate library ensures eventual end; this is NOT an Oracle-level decking rule.
 int commanders[4][2],cmdcount[4]={};
 for(int p=0;p<4;p++){
  auto &s=P[p];auto &deck=cards[phase][p];
  for(int i=0;i<100;i++)if(deck[i].cmd)commanders[p][cmdcount[p]++]=i;
  for(int i=0;i<100;i++)if(!deck[i].cmd)s.library[s.libn++]=i;
  for(int k=0;k<7;k++){
   int j=k+rng.ir(s.libn-k);swap(s.library[k],s.library[j]);
   int id=s.library[k];s.hand[s.handn++]=id;agg.stat[p][id].drawn++;
  }
  s.drawpos=7;
 }
 int winner=-1,rounds=0;
 for(int round=0;;round++){
  rounds=round+1;
  for(int step=0;step<4;step++){
   int p=(starting+step)%4; State &s=P[p];if(!s.active)continue;
   auto &deck=cards[phase][p];
   // Opening-player draw is enabled in 4-player Commander.
   int draws=1+min(2,int(s.extraDraw));s.extraDraw=max(0.,s.extraDraw-1.0);
   for(int j=0;j<draws;j++){
    if(s.drawpos>=s.libn){s.life=-100;break;}
    int k=s.drawpos+rng.ir(s.libn-s.drawpos);swap(s.library[s.drawpos],s.library[k]);
    int cid=s.library[s.drawpos++];s.hand[s.handn++]=cid;agg.stat[p][cid].drawn++;
   }
   if(s.life<=0){s.active=false;continue;}
   // One land per turn: colored sources not modeled, no fetch/cast choices.
   for(int i=0;i<s.handn;i++)if(deck[s.hand[i]].land){
    int cid=s.hand[i];s.hand[i]=s.hand[--s.handn];
    s.lands++;s.used[cid]=true;agg.played_events++;agg.stat[p][cid].played++;agg.stat[p][cid].utility+=.47/(1+.035*round);break;
   }
   int mana=int(s.lands+s.resource);s.counter=0;
   // Prioritized main-phase casting. Counterspells simplified to suppression counters.
   for(int action=0;action<4 && mana>0;action++){
    int best=-1;double bestV=-1;
    int cmdindex=-1;
    for(int i=0;i<s.handn+cmdcount[p];i++){
     int cid=(i<s.handn)?s.hand[i]:commanders[p][i-s.handn];
     auto &c=deck[cid]; if(c.land)continue;
     int ci=-1;
     for(int z=0;z<cmdcount[p];z++)if(commanders[p][z]==cid)ci=z;
     if(ci>=0 && s.cmd_active[ci])continue;
     int cost=c.mana+(ci>=0?2*s.cmd_casts[ci]:0);
     if(cost>mana)continue;
     double policy=0.;
     switch(c.role){
      case RAMP: policy=1.5+(round<5?2.5:round<9?1.:0.); break;
      case DRAW:policy=2.5+(s.handn<3?1.:0.);break;
      case REMOVE:policy=2.0;break;
      case COUNTER:policy=2.0;break;
      case WIPE:policy=1.0;break;
      case ENGINE:policy=2.4+(round<9?1.:0.);break;
      case EQUIP:policy=1.8+((s.cmd_active[0]||s.cmd_active[1])?2.2:0.);break;
      case PROTECT:policy=1.0+((s.cmd_active[0]||s.cmd_active[1])?1.8:0.);break;
      case BLINK:policy=1.8+s.eng*.35;break;
      case REANIMATE:policy=2.3+s.eng*.2;break;
      case FINISH:policy=3.6;break;
      default:policy=2.5;
     }
     if(ci>=0){policy+=p==0?1.1:p==1?2.:p==2?1.4:.6;}
     double value=policy+min(3.,cost*.18)+rng.uni()*.5;
     if(value>bestV){bestV=value;best=cid;cmdindex=ci;}
    }
    if(best<0)break;
    const Card &c=deck[best];int cost=c.mana+(cmdindex>=0?2*s.cmd_casts[cmdindex]:0);
    if(trace){
       double minlife=1e4,maxboard=0.;
       for(int q=0;q<4;q++)if(q!=p && P[q].active){minlife=min(minlife,P[q].life);maxboard=max(maxboard,P[q].board);}
       episode.push_back({double(phase),double(p),double(round+1),double(mana),double(s.lands),double(s.handn),s.life,s.board,s.eng,minlife,maxboard,double(c.role),double(cmdindex>=0)});
    }
    mana-=cost;
    // Approximate observed-window and synthetic response policy; NOT Oracle-legal instant speed interaction.
    // Phase 0 preserves the historical heuristic; phase 1 uses frozen independently learned card priors.
    int other=-1;double danger=-1;
    for(int q=0;q<4;q++)if(q!=p&&P[q].active){double d=P[q].board+P[q].eng+P[q].gear+max(0.,40.-P[q].life)*.16;
     if(AUDIT_MODE==3){ // All decks: focus repeatable high-pressure engines and exposed commander threats.
       d+=P[q].gear*2.0 + (P[q].cmd_active[0] ? 3.5 : 0.) + (P[q].cmd_active[1] ? 1.5 : 0.);
       d+=min(5.0,P[q].board*.28);
     }
     d+=P[q].resent[p]*.3;
     if(policy_mode==1) d+= max(0.,40.-P[q].life)*.08 + P[q].eng*.4;
     if(d>danger){danger=d;other=q;}}
    double impact=.25;
    bool fizzled=false;
    if(policy_mode==0){
      if(c.role!=LAND && c.role!=RAMP){
        bool potential=false;
        for(int q=0;q<4;q++)if(q!=p&&P[q].active&&P[q].counter>0){potential=true;break;}
        if(potential)agg.stat[p][best].eligible_response_windows++;
        if(other>=0&&P[other].counter>0 && rng.uni()<.08*P[other].counter){fizzled=true;P[other].counter--;}
      }
    }else if(c.role!=LAND && c.role!=RAMP){
      int defender=-1;double highest=-1e9;
      for(int q=0;q<4;q++)if(q!=p&&P[q].active&&P[q].counter>0){
        // Interventions remain modeled abstractions: counters are surrogate resources.
        double imminent=(P[q].life<18?1.3:0.)+(P[p].board>8?1.1:0.);
        double threat=c.prior*.60+imminent+(c.cmd?1.3:0.) +
           (c.role==FINISH?1.2:c.role==ENGINE?0.8:c.role==WIPE?0.7:c.role==COUNTER?0.5:0.);
        double reserve=1.7 + (P[q].counter==1?1.5:0.) + (c.mana<=2?0.4:0.);
        double delta=threat-reserve + 0.15*P[q].resent[p];
        if(delta>highest){highest=delta;defender=q;}
      }
      if(defender>=0){
        agg.stat[p][best].eligible_response_windows++;
        // A minimum advantage threshold protects the last response from routine plays.
        if(highest>0.75){fizzled=true;P[defender].counter--;}
      }
    }
    if(fizzled){agg.stat[p][best].interventions++;agg.stat[p][best].denied_value_proxy+=c.prior;}
    if(!fizzled){
     // Audit modes remove historical double counting of commanders as both generic
     // "finisher/threat" and commander-specific board tokens. Not legal MTG combat.
     if((AUDIT_MODE==1 || AUDIT_MODE==2 || AUDIT_MODE==3 || AUDIT_MODE==5) && cmdindex>=0){impact=1.0;}
     else switch(c.role){
      case RAMP:s.resource+= (cost<=2? .95:1.2);impact=1.45/(1.+.07*round);break;
      case DRAW:s.extraDraw+=1.5;impact=1.2;break;
      case COUNTER:s.counter+=2;impact=.8;break;
      case REMOVE:if(other>=0){agg.removal_targeted[other]++;double sub=min(P[other].board,2.+cost*.6);P[other].board-=sub;impact=1.+sub*.4;
        for(int ci=0;ci<cmdcount[other];ci++)if(P[other].cmd_active[ci]&&rng.uni()<(AUDIT_MODE==3?.45:.13)){
            P[other].cmd_active[ci]=false;impact+=1.2;
            if((AUDIT_MODE==2 || AUDIT_MODE==3) && ci==0){P[other].gear_waiting+=P[other].gear;P[other].gear=0;}
          }}
       break;
      case WIPE:{double removed=0;for(int q=0;q<4;q++)if(q!=p){removed+=P[q].board*.55;P[q].board*=.38;
          for(int ci=0;ci<cmdcount[q];ci++)if(P[q].cmd_active[ci]&&rng.uni()<.35){
            P[q].cmd_active[ci]=false;
            if((AUDIT_MODE==2 || AUDIT_MODE==3) && ci==0){P[q].gear_waiting+=P[q].gear;P[q].gear=0;}
          }}
        s.board*=.62;impact=1.+removed*.25;break;}
      case PROTECT:s.shield+=1.+cost*.20;impact=.9+s.board*.05;break;
      case EQUIP:
        if((AUDIT_MODE==2 || AUDIT_MODE==3)){s.gear_waiting+=1.+cost*.36;impact=.2;} // Deferred until proxy equip activation
        else {s.gear+=1.+cost*.36;impact=.6+(s.cmd_active[0]||s.cmd_active[1]?1.2:0);}
        break;
      case ENGINE:s.eng+=1.+cost*.17; s.board+=.2;impact=1.1+1.1/(1.+.07*round);break;
      case BLINK:s.extraDraw+=.25;s.board+=.5+s.eng*.16;impact=1.1+s.eng*.28;break;
      case REANIMATE:s.board+=1.2+cost*.25+s.eng*.10;impact=1.3+s.eng*.12;break;
      case FINISH:s.board+=2.5+cost*.55;impact=2.+cost*.26;break;
      default:s.board+=1.4+cost*.45;impact=1.2+cost*.15;
     }
     // Commander-specific approximate enablers. None of this resolves Oracle accurately.
     if(cmdindex>=0){s.cmd_casts[cmdindex]++;s.cmd_active[cmdindex]=true;
       if(p==0){s.eng+=1.4;impact+=1.3;}
       if(p==1){s.board+=(AUDIT_MODE==1 || AUDIT_MODE==2 || AUDIT_MODE==3 || AUDIT_MODE==5)?6.:4.5;impact+=2.5;}
       if(p==2){s.board+=(AUDIT_MODE==1 || AUDIT_MODE==2 || AUDIT_MODE==3 || AUDIT_MODE==5)?6.:4.0;s.extraDraw+=1;impact+=1.8;}
       if(p==3 && c.name.find("Livio")!=string::npos){s.eng+=.6;if(AUDIT_MODE==1 || AUDIT_MODE==2 || AUDIT_MODE==3 || AUDIT_MODE==5)s.board+=2.;impact+=.9;}
       if(p==3 && c.name.find("Ikra")!=string::npos){s.board+=3.;impact+=1.5;}
     }
     // Deck-specific pattern estimates: spell recursion, equip commander, demon ETBs, Abzan ETBs.
     if(p==0 && (c.name=="Talrand, Sky Summoner" || c.name=="Shark Typhoon")){
       s.spellslinger+=(c.name=="Shark Typhoon"?1.7:1.2);impact+=1.4;
     }
     if(p==0 && (c.role==DRAW||c.role==COUNTER||c.role==REMOVE||c.role==RAMP)){
       impact+=.11*s.eng;
       if(s.spellslinger>0){double tokens=s.spellslinger*(.80+min(2.,s.eng*.10));s.board+=tokens;impact+=tokens*.5;}
     }
     if(p==1 && c.role==EQUIP && (AUDIT_MODE!=2 && AUDIT_MODE!=3)){s.gear+=.6;impact+=s.cmd_active[0]?1.5:0;}
     if(p==2 && c.name=="Sneak Attack"){
       s.sneak=1.;s.board+=1.2;impact+=2.5;
     }
     if(p==2 && s.sneak>0 && (c.role==THREAT||c.role==FINISH||c.role==REANIMATE)){
       s.board+=1.3;impact+=1.3;
     }
     if(p==2 && (c.role==THREAT||c.role==FINISH||c.role==REANIMATE) && s.cmd_active[0] && other>=0){
       double ping=min(4.,1.+cost*.55);P[other].life-=ping;impact+=ping*.4;
     }
     if(p==3 && (c.role==BLINK||c.role==REANIMATE||c.role==THREAT)){
       double v=min(2.5,s.eng*.10);s.board+=v;impact+=v*.4;
     }
    }
    s.used[best]=true;agg.played_events++;agg.stat[p][best].played++;agg.stat[p][best].utility+=impact;
    if(cmdindex<0){for(int i=0;i<s.handn;i++)if(s.hand[i]==best){s.hand[i]=s.hand[--s.handn];break;}}
   }
   // Equipment audit: an equipment spell no longer gives free, instant, permanent damage.
   // Activate at most one proxy equipment attachment after casts (2 generic mana ASSUMED,
   // not the actual printed equip cost). Only to the active commander in this scenario.
   if((AUDIT_MODE==2 || AUDIT_MODE==3) && s.cmd_active[0] && mana>=2 && s.gear_waiting>0){
     mana-=2;s.gear+=s.gear_waiting;s.gear_waiting=0;agg.equipment_attaches[p]++;
   }
   // Free-for-all combat, simplified blocking; protect and retaliation influence politics.
   int target=-1;double tvalue=-1e9;
   for(int q=0;q<4;q++)if(q!=p&&P[q].active){
    double appeal=(P[q].board+P[q].eng*1.3+P[q].gear*.5)*.15 + (40.-P[q].life)*.08;
    appeal+=P[q].resent[p]*.18;
    appeal-=P[q].board*.05;
    if(AUDIT_MODE==3){ // Public board/commander pressure increases political attack targeting.
      double cmd_pressure=P[q].cmd_active[0] ? (q==1?6.:q==2?4.:2.5) : 0.;
      appeal+=(cmd_pressure+P[q].gear*1.7+P[q].eng*.7)*.65;
    }
    appeal+=rng.uni()*1.8;
    if(appeal>tvalue){tvalue=appeal;target=q;}
   }
   if(target>=0){
    agg.attacks_received[target]++;
    State &d=P[target];double raw=(s.board*1.22+s.gear*1.15+(s.cmd_active[0]?p==1?4.2:3.0:0))*(.64+.30*rng.uni());
    double blocked=d.board*.15+(d.shield*.68);
    double dealt=clampd(raw-blocked,0,27);d.life-=dealt;
    s.resent[target]++;d.resent[p]++;
    if(p==3 && s.cmd_active[1])s.life=min(75.,s.life+dealt*.23);
    // Legacy mode credits a fraction of *all* attacking creatures' combat damage to the commander.
    // Audited mode separately estimates the commander's individual source contribution.
    if(AUDIT_MODE==0 || AUDIT_MODE==5){
      if(p==1 && s.cmd_active[0] && dealt>0){d.cmd_dmg[p][0]+=dealt*.68;agg.commander_damage_estimated[p]+=dealt*.68;
       if(d.cmd_dmg[p][0]>=21){d.life=-101;agg.commander_damage_eliminations[p]++;}}
      if(p==2 && s.cmd_active[0] && dealt>0){d.cmd_dmg[p][0]+=dealt*.40;agg.commander_damage_estimated[p]+=dealt*.40;
       if(d.cmd_dmg[p][0]>=21){d.life=-101;agg.commander_damage_eliminations[p]++;}}
      if(p==3 && s.cmd_active[1] && dealt>0){d.cmd_dmg[p][1]+=dealt*.28;agg.commander_damage_estimated[p]+=dealt*.28;
       if(d.cmd_dmg[p][1]>=21){d.life=-101;agg.commander_damage_eliminations[p]++;}}
    }else if(dealt>0){
      int index=(p==3?1:0);
      bool active=s.cmd_active[index];
      if(active){
       // Base-power approximation, not actual combat assignment, evasions or keyword handling.
       double base=(p==0?3.:(p==1?6.:(p==2?6.:(p==3?3.:0.))));
       double gear=(p==1?max(0.,s.gear):0.);
       double estimate=max(0.,base+gear*.65-blocked*.40);
       double allocated=min(dealt,estimate);
       d.cmd_dmg[p][index]+=allocated;agg.commander_damage_estimated[p]+=allocated;
       if(d.cmd_dmg[p][index]>=21){d.life=-101;agg.commander_damage_eliminations[p]++;}
      }
    }
    // combat board attrition, not precise MTG creature damage.
    s.board=max(0.,s.board- d.board*.018);
   }
   s.shield*=.88;
   for(int q=0;q<4;q++)if(P[q].life<=0)P[q].active=false;
   int count=0,last=-1;for(int q=0;q<4;q++)if(P[q].active){count++;last=q;}
   if(count==1){winner=last;goto done;}if(count==0){goto done;}
  }
 }
 done:
 if(trace){for(auto &ev:episode){(*trace)<<seed;for(double x:ev)(*trace)<<","<<x;(*trace)<<","<<winner<<"\n";}}
 agg.total++;agg.turns+=rounds;agg.round_hist[min(128,rounds)]++;
 if(winner>=0){agg.win[winner]++;agg.ended++;}else agg.draw++;
 for(int p=0;p<4;p++)if(winner==p)for(int id=0;id<100;id++)if(P[p].used[id])agg.stat[p][id].win_played++;
 return {winner,rounds};
}
void write_report(const string &path,const vector<Card> cards[2][4],Agg agg[2],uint64_t paired[5][5],uint64_t n,uint64_t offset){
 ofstream f(path);f<<fixed<<setprecision(7);
 f<<"{\n \"metadata\":{\"simulator\":\"v0.7 matched-policy strategic surrogate - NOT MTG rules\",\"seed\":424242,\"paired_trials\":"<<n<<",\"seed_pair_offset\":"<<offset<<",\"total_four_player_games\":"<<n*2<<",\"cap_turns\":null,\"artificial_turn_limit\":false,\"decks_per_game\":4,\"positions_fixed\":true},\n \"phases\":[";
 for(int phase=0;phase<2;phase++){
  if(phase)f<<",";auto &a=agg[phase];f<<"{\"phase\":\""<<(FIXED_POLICY_MODE>=0?(phase?"candidate_same_policy":"baseline_same_policy"):(phase?"threat_aware":"frozen_heuristic"))<<"\",\"games\":"<<a.total<<",\"draws\":0,\"unresolved_surrogate\":"<<a.draw<<",\"technical_interruptions\":0,\"mean_rounds\":"<<(a.turns/a.total)<<",\"total_rounds\":"<<a.turns<<",\"played_events\":"<<a.played_events<<",\"round_histogram\":[";for(int k=0;k<129;k++){if(k)f<<",";f<<a.round_hist[k];}f<<"],\"starting_counts\":[";for(int k=0;k<4;k++){if(k)f<<",";f<<a.start_counts[k];}f<<"],\"audit_mode\":"<<AUDIT_MODE<<",\"attacks_received\":[";
  for(int k=0;k<4;k++){if(k)f<<",";f<<a.attacks_received[k];}
  f<<"],\"removal_targeted\":[";
  for(int k=0;k<4;k++){if(k)f<<",";f<<a.removal_targeted[k];}
  f<<"],\"commander_damage_eliminations\":[";
  for(int k=0;k<4;k++){if(k)f<<",";f<<a.commander_damage_eliminations[k];}
  f<<"],\"commander_damage_estimated\":[";
  for(int k=0;k<4;k++){if(k)f<<",";f<<a.commander_damage_estimated[k];}
  f<<"],\"equipment_attach_proxies\":[";
  for(int k=0;k<4;k++){if(k)f<<",";f<<a.equipment_attaches[k];}
  f<<"],\"wins\":[";
  for(int p=0;p<4;p++){if(p)f<<",";double wr=double(a.win[p])/a.total, se=sqrt(wr*(1-wr)/a.total);
   f<<"{\"deck\":"<<p+1<<",\"wins\":"<<a.win[p]<<",\"win_rate\":"<<wr<<",\"ci95_approx\":["<<max(0.,wr-1.96*se)<<","<<min(1.,wr+1.96*se)<<"]}";}
  f<<"],\"card_events\":[";
  bool first=true;
  for(int p=0;p<4;p++)for(int j=0;j<100;j++){
   if(!first)f<<",";first=false;const auto &c=cards[phase][p][j];const auto &s=a.stat[p][j];
   // JSON escaping for card names
   string nm=c.name;string esc;for(char z:nm){if(z=='"'||z=='\\')esc+='\\';esc+=z;}
   f<<"{\"deck\":"<<p+1<<",\"index\":"<<j<<",\"card\":\""<<esc<<"\",\"role\":\""<<role_name(c.role)<<"\",\"estimated_mana\":"<<c.mana<<",\"land\":"<<(c.land?"true":"false")<<",\"commander\":"<<(c.cmd?"true":"false")<<",\"drawn\":"<<s.drawn<<",\"played\":"<<s.played<<",\"wins_with_play\":"<<s.win_played<<",\"observed_utility_total\":"<<(double)s.utility<<",\"frozen_threat_prior\":"<<c.prior<<",\"eligible_response_windows\":"<<s.eligible_response_windows<<",\"interventions\":"<<s.interventions<<",\"denied_value_proxy\":"<<(double)s.denied_value_proxy<<"}";
  }
  f<<"]}";
 }
 f<<"],\"paired_outcomes\":[";
 for(int p=0;p<5;p++){if(p)f<<",";f<<"[";for(int q=0;q<5;q++){if(q)f<<",";f<<paired[p][q];}f<<"]";}
 f<<"]}\n";
}
int main(int argc,char**argv){
 string root=argc>1?argv[1]:".",csv=root+"/profiles.csv";int n=argc>2?stoi(argv[2]):500000;
 vector<Card> cards[2][4];ifstream in(csv);string line;getline(in,line);
 while(getline(in,line)){
  if(!line.empty() && line.back()=='\r') line.pop_back(); // CRLF: otherwise every commander flag was falsely parsed as false.
  vector<string> c=split(line,'|');if(c.size()!=8){cerr<<"Bad CSV: "<<line<<"\n";return 1;}
  int ph=c[0]=="updated"?1:0,p=stoi(c[1]),id=stoi(c[2]);
  if(id!=(int)cards[ph][p].size()){cerr<<"Card id ordering issue\n";return 2;}
  cards[ph][p].push_back({p,id,stoi(c[5]),c[6]=="True",c[7]=="True",to_role(c[4]),c[3],2.5});
 }
 for(int ph=0;ph<2;ph++)for(int p=0;p<4;p++){
  if(cards[ph][p].size()!=100){cerr<<"Deck doesn't have 100 cards\n";return 3;}
  int count=0;for(auto &card:cards[ph][p])if(card.cmd)count++;
  if(count!=(p==3?2:1)){cerr<<"COMMANDER PARSE FAILURE: phase "<<ph<<" seat "<<p<<" saw "<<count<<" commanders\n";return 5;}
 }
 // Frozen model-prior file must be present and match all unique names in the four accepted decks.
 string priorfile=root+"/data/frozen_card_priors.tsv";
 map<pair<int,string>,double> priors;ifstream pin(priorfile);if(!pin){cerr<<"MISSING_FROZEN_PRIORS\n";return 9;}
 getline(pin,line);
 while(getline(pin,line)){
  if(!line.empty()&&line.back()=='\r')line.pop_back();
  auto fields=split(line,'\t');if(fields.size()!=3){cerr<<"INVALID_PRIOR_ROW\n";return 9;}
  double v=stod(fields[2]);if(!isfinite(v)||v<0){cerr<<"INVALID_PRIOR_VALUE\n";return 9;}
  priors[{stoi(fields[0]),fields[1]}]=v;
 }
 for(int ph=0;ph<2;ph++)for(int seat=0;seat<4;seat++)for(auto &card:cards[ph][seat]){
  auto it=priors.find({seat,card.name});if(it==priors.end()){cerr<<"MISSING_PRIOR: "<<seat<<"/"<<card.name<<"\n";return 10;}
  card.prior=it->second;
 }
 if(const char* audit=getenv("COMMANDERSIM_AUDIT_MODE")){
   AUDIT_MODE=stoi(audit);if(AUDIT_MODE<0||AUDIT_MODE>5){cerr<<"BAD_AUDIT_MODE\n";return 14;}
 }
 if(const char* mode=getenv("COMMANDERSIM_FIXED_POLICY")){ FIXED_POLICY_MODE=stoi(mode); if(FIXED_POLICY_MODE<0||FIXED_POLICY_MODE>1){cerr<<"BAD_FIXED_POLICY\n";return 12;} }
 for(int seat=0;seat<4;seat++)for(int id=0;id<100;id++)if(FIXED_POLICY_MODE<0 && cards[0][seat][id].name!=cards[1][seat][id].name){cerr<<"POLICY_AB_REQUIRES_IDENTICAL_DECKS\n";return 11;}
 int isolate=argc>3?stoi(argv[3]):-1;
 uint64_t offset=argc>4?stoull(argv[4]):0;
 string outfile=argc>5?argv[5]:root+(isolate>=0?"/reports/isolated_seat_"+to_string(isolate+1)+".json":"/simulation_raw.json");
 ofstream winner_file;
 if(const char* path=getenv("COMMANDERSIM_GAME_CSV")){
   winner_file.open(path);if(!winner_file)return 18;
   winner_file<<"seed,phase,winner,rounds,audit_mode\n";
 }
 ofstream trace_file; if(argc>6){trace_file.open(argv[6]);if(!trace_file){cerr<<"Unable to open trajectory path\n";return 11;}trace_file<<"seed,phase,seat,table_round,mana,lands,own_hand_count,own_life,own_board,own_engine,opponent_min_life,opponent_max_board,chosen_role,chosen_commander,winner\n";}
 if(isolate>=0){
   if(isolate>3){cerr<<"Seat for isolation is 0..3\n";return 4;}
   for(int q=0;q<4;q++)if(q!=isolate)cards[0][q]=cards[1][q];
 }
 Agg agg[2]; uint64_t pairs[5][5]={};
 auto begin=chrono::steady_clock::now();
 for(int i=0;i<n;i++){
  uint64_t seed=0x9e3779b97f4a7c15ULL*(uint64_t(i)+offset+1) + 424242;
  auto a=play(cards,0,seed,agg[0],trace_file.is_open()?&trace_file:nullptr);
  auto b=play(cards,1,seed,agg[1],trace_file.is_open()?&trace_file:nullptr);
  if(winner_file){winner_file<<seed<<",0,"<<a.winner<<","<<a.rounds<<","<<AUDIT_MODE<<"\n";
                  winner_file<<seed<<",1,"<<b.winner<<","<<b.rounds<<","<<AUDIT_MODE<<"\n";}
  pairs[a.winner>=0?a.winner:4][b.winner>=0?b.winner:4]++;
 }
 auto secs=chrono::duration<double>(chrono::steady_clock::now()-begin).count();
 write_report(outfile,cards,agg,pairs,n,offset);
 cerr<<"EXECUTED "<<n*2<<" four-seat surrogate games in "<<secs<<"s; baseline wins ";
 for(auto a:agg[0].win)cerr<<a<<" ";cerr<<"draws "<<agg[0].draw<<"; updated wins ";
 for(auto a:agg[1].win)cerr<<a<<" ";cerr<<"draws "<<agg[1].draw<<"\n";
}
