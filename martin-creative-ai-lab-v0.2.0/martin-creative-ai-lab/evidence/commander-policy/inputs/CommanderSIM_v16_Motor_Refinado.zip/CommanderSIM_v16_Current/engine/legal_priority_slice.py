"""Bounded, deterministic MTG priority/target/payment slice (NOT a general rules engine).

Exact supported spells in this fixture: Counterspell (UU, counter target spell)
and Go for the Throat (1B, destroy target nonartifact creature). Battlefield
Palladia-Mors conditional hexproof is supported solely as a targeting predicate.
The other 300+ card mechanics, complete game lifecycle and Oracle remain unsupported.

A scenario fixture moves owned cards from library to hand and injects a pending
spell or battlefield permanent; it is NOT a naturally played game.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, field
from collections import Counter
from pathlib import Path
import hashlib, json, random

COMMANDERS = (
    ("Dralnu, Lich Lord",),
    ("Palladia-Mors, the Ruiner",),
    ("Be'lakor, the Dark Master",),
    ("Livio, Oathsworn Sentinel", "Ikra Shidiqi, the Usurper"),
)
NAMES = ('01_Dralnu','02_Palladia','03_Belakor','04_Abzan')
BASIC = {'Plains','Island','Swamp','Mountain','Forest','Wastes',
         'Snow-Covered Plains','Snow-Covered Island','Snow-Covered Swamp',
         'Snow-Covered Mountain','Snow-Covered Forest','Snow-Covered Wastes'}
SUPPORTED = {'Counterspell','Go for the Throat'}

class UnsupportedInteraction(RuntimeError): pass
class IllegalAction(RuntimeError): pass

@dataclass
class StackObject:
    sid: int
    name: str
    controller: int
    owner: int
    commander: bool = False
    target_sid: int | None = None
    target_pid: int | None = None

@dataclass
class Permanent:
    pid: int
    name: str
    owner: int
    controller: int
    is_creature: bool = True
    is_artifact: bool = False
    has_dealt_damage: bool = False

@dataclass
class Seat:
    name: str
    commanders: tuple[str, ...]
    library: list[str]
    command: list[str]
    hand: list[str] = field(default_factory=list)
    graveyard: list[str] = field(default_factory=list)
    mana: dict[str,int] = field(default_factory=dict)


def read_counts(path: Path) -> Counter:
    out=Counter()
    for raw in path.read_text(encoding='utf-8-sig').splitlines():
        if raw.strip():
            n,card=raw.strip().split(' ',1)
            if not n.isdigit() or int(n)<1:raise ValueError('Malformed deck line')
            out[card]+=int(n)
    return out

class BoundedGame:
    def __init__(self, deck_folder:Path, seed:int, starting_seat:int=0):
        if starting_seat not in range(4):raise ValueError('Starting seat outside four-player table')
        self.seed=seed;self.starter=starting_seat;self.rng=random.Random(seed)
        self.seats=[];self.stack=[];self.permanents=[];self.events=[]
        self.priority_seat=starting_seat;self.pass_count=0;self.seq=0;self.next_object=1
        for i,n in enumerate(NAMES):
            counts=read_counts(deck_folder/(n+'.txt'))
            if sum(counts.values())!=100:raise ValueError('Deck must contain exactly 100 cards')
            if any(q>1 and card not in BASIC for card,q in counts.items()):raise ValueError('Singleton violation')
            if any(counts[c]!=1 for c in COMMANDERS[i]):raise ValueError('Commander configuration changed')
            for c in COMMANDERS[i]:counts[c]-=1
            lib=[name for name,q in counts.items() for _ in range(q)]
            self.rng.shuffle(lib)
            self.seats.append(Seat(n,COMMANDERS[i],lib,list(COMMANDERS[i])))
        if len(self.seats)!=4:raise ValueError('Exactly four decks')
    def _event(self, kind, **detail):
        self.seq+=1;self.events.append({'seq':self.seq,'type':kind,**detail})
    def fixture_draw_specific(self, seat:int, card:str):
        """Preset state only: deterministic scenario, not simulated random draw."""
        self.seats[seat].library.remove(card)
        self.seats[seat].hand.append(card)
        self._event('fixture_set_hand',seat=seat,card=card)
    def fixture_mana(self, seat:int, **pool):
        if any(c not in 'WUBRGC' or (not isinstance(n,int)) or n<0 for c,n in pool.items()):raise ValueError('bad pool')
        self.seats[seat].mana=pool.copy()
        self._event('fixture_set_mana',seat=seat,pool=pool)
    def fixture_spell_on_stack(self,owner:int,name:str):
        """Only supports the expressly modeled opposing Be'lakor spell fixture."""
        if owner!=2 or name!="Be'lakor, the Dark Master":raise UnsupportedInteraction('Only Be\'lakor stack fixture supported')
        if name not in self.seats[owner].command:raise IllegalAction('Commander not in command zone')
        self.seats[owner].command.remove(name)
        sid=self.next_object;self.next_object+=1
        self.stack.append(StackObject(sid,name,owner,owner,commander=True))
        self.priority_seat=(owner+1)%4;self.pass_count=0
        self._event('fixture_stack_cast',sid=sid,owner=owner,name=name,notice='commander mana payment intentionally not modeled in fixture')
        return sid
    def fixture_permanent(self,owner:int,name:str,has_dealt_damage=False):
        if owner!=1 or name!="Palladia-Mors, the Ruiner":raise UnsupportedInteraction('Only Palladia permanent fixture supported')
        if name not in self.seats[owner].command:raise IllegalAction('Commander not in command')
        self.seats[owner].command.remove(name)
        pid=self.next_object;self.next_object+=1
        self.permanents.append(Permanent(pid,name,owner,owner,has_dealt_damage=has_dealt_damage))
        self._event('fixture_battlefield',pid=pid,owner=owner,name=name)
        return pid
    @staticmethod
    def _can_pay(pool:dict,card:str)->bool:
        colors=Counter(pool)
        if card=='Counterspell':return colors['U']>=2
        if card=='Go for the Throat':
            return colors['B']>=1 and sum(colors.values())>=2
        return False
    @staticmethod
    def _pay(pool:dict,card:str)->dict:
        spent={}
        if card=='Counterspell':pool['U']-=2;spent={'U':2}
        elif card=='Go for the Throat':
            pool['B']-=1;spent={'B':1}
            for c in 'C W U B R G'.split():
                if pool.get(c,0)>0:
                    pool[c]-=1;spent[c]=spent.get(c,0)+1;break
            else:raise IllegalAction('No generic mana')
        else:raise UnsupportedInteraction(card)
        return spent
    def legal_actions(self,seat:int)->list[dict]:
        if seat!=self.priority_seat:raise IllegalAction('Not your priority')
        out=[{'kind':'pass','action_id':'pass'}]
        player=self.seats[seat]
        if 'Counterspell' in player.hand and self._can_pay(player.mana,'Counterspell'):
            for entry in self.stack:
                # Supported stack objects have no uncounterable property.
                if entry.name not in ("Be'lakor, the Dark Master",'Counterspell','Go for the Throat'):
                    continue
                out.append({'kind':'interact','action_id':'cast_counterspell','target_sid':entry.sid,
                            'target_card':entry.name,'target_seat':entry.controller,
                            'resource_opportunity_cost':0.3,'public_immediate_win_risk':1.0})
        if 'Go for the Throat' in player.hand and self._can_pay(player.mana,'Go for the Throat'):
            for p in self.permanents:
                if not p.is_creature or p.is_artifact:continue
                hexproof=(p.name=='Palladia-Mors, the Ruiner' and not p.has_dealt_damage)
                if hexproof and seat!=p.controller:continue
                out.append({'kind':'interact','action_id':'cast_go_for_the_throat','target_pid':p.pid,
                            'target_card':p.name,'target_seat':p.controller,
                            'resource_opportunity_cost':0.3,'public_immediate_win_risk':1.0})
        return out
    def observation(self,seat:int)->dict:
        return {'seat':seat,'own_hand':list(self.seats[seat].hand),
                'public_state':{'priority':self.priority_seat,'stack':[{'sid':o.sid,'name':o.name,'controller':o.controller} for o in self.stack],
                'battlefield':[{'pid':p.pid,'name':p.name,'controller':p.controller,'dealt_damage':p.has_dealt_damage} for p in self.permanents],
                'available_mana':dict(self.seats[seat].mana)},
                'legal_actions':self.legal_actions(seat)}
    def perform(self,seat:int,action:dict):
        if action not in self.legal_actions(seat):raise IllegalAction('Action absent from verified bounded legal set')
        kind=action['action_id']
        if kind=='pass':
            self._event('pass_priority',seat=seat)
            self.pass_count+=1
            if self.pass_count==4:
                self.pass_count=0
                if self.stack:self._resolve_top()
                else:self._event('priority_window_finished')
                self.priority_seat=self.starter  # Active player gets priority after resolution in this fixture.
            else:self.priority_seat=(seat+1)%4
            return
        card='Counterspell' if kind=='cast_counterspell' else 'Go for the Throat'
        player=self.seats[seat]
        paid=self._pay(player.mana,card)
        player.hand.remove(card)
        sid=self.next_object;self.next_object+=1
        self.stack.append(StackObject(sid,card,seat,seat,target_sid=action.get('target_sid'),target_pid=action.get('target_pid')))
        self._event('cast',sid=sid,seat=seat,card=card,paid=paid,target_sid=action.get('target_sid'),target_pid=action.get('target_pid'))
        self.pass_count=0
        self.priority_seat=seat # Caster receives priority after completing cast.
    def _resolve_top(self):
        spell=self.stack.pop()
        if spell.name=='Counterspell':
            victim=next((o for o in self.stack if o.sid==spell.target_sid),None)
            if victim is None:self._event('fizzle',sid=spell.sid)
            else:
                self.stack.remove(victim)
                self._event('countered',source_sid=spell.sid,target_sid=victim.sid,target_name=victim.name)
                if victim.commander:
                    # Explicit owner choice in fixture; command-zone movement is an SBA,
                    # not a replacement before graveyard entry.
                    self.seats[victim.owner].graveyard.append(victim.name)
                    self._event('to_graveyard',card=victim.name,seat=victim.owner)
                    self.seats[victim.owner].graveyard.remove(victim.name)
                    self.seats[victim.owner].command.append(victim.name)
                    self._event('commander_sba_command',card=victim.name,seat=victim.owner)
                else:self.seats[victim.owner].graveyard.append(victim.name)
        elif spell.name=='Go for the Throat':
            victim=next((p for p in self.permanents if p.pid==spell.target_pid),None)
            if (victim is None or victim.is_artifact or
                (victim.name=='Palladia-Mors, the Ruiner' and not victim.has_dealt_damage and victim.controller!=spell.controller)):
                self._event('fizzle',sid=spell.sid)
            else:
                self.permanents.remove(victim)
                self.seats[victim.owner].graveyard.append(victim.name)
                self._event('destroy',target_pid=victim.pid,name=victim.name)
                if victim.name in self.seats[victim.owner].commanders:
                    self.seats[victim.owner].graveyard.remove(victim.name)
                    self.seats[victim.owner].command.append(victim.name)
                    self._event('commander_sba_command',card=victim.name,seat=victim.owner)
        elif spell.name=="Be'lakor, the Dark Master":
            self._event('unsupported_resolution',sid=spell.sid,name=spell.name)
            raise UnsupportedInteraction('Be\'lakor ETB is NOT executed by bounded priority slice')
        else:raise UnsupportedInteraction(spell.name)
        self.seats[spell.owner].graveyard.append(spell.name)
        self._event('resolved',sid=spell.sid,name=spell.name)
    def export_trace(self)->dict:
        return {'coverage':'VERIFIED_BOUNDED_RULE_SLICE_NOT_FULL_GAME','seed':self.seed,
                'starter':self.starter,'decks':[{'seat':i,'name':x.name,'commanders':list(x.commanders),
                'total_cards':len(x.library)+len(x.hand)+len(x.command)+len(x.graveyard)+sum(p.owner==i for p in self.permanents)+sum(o.owner==i for o in self.stack)} for i,x in enumerate(self.seats)],
                'events':self.events}

def play_counterspell_fixture(deck_folder:Path,seed:int=37,starter:int=0,policy=None)->dict:
    g=BoundedGame(deck_folder,seed,starter)
    target=g.fixture_spell_on_stack(2,"Be'lakor, the Dark Master")
    g.fixture_draw_specific(0,'Counterspell')
    g.fixture_mana(0,U=2)
    g.perform(3,{'kind':'pass','action_id':'pass'})
    from threat_policy import ContextualThreatPolicy,PolicyInput
    if policy is None:policy=ContextualThreatPolicy({(2,"Be'lakor, the Dark Master"):6.0},'bounded-v08')
    obs=g.observation(0)
    choice=policy.choose(PolicyInput(0,tuple(obs['own_hand']),obs['public_state'],tuple(obs['legal_actions']),True))
    g.perform(0,choice)
    # After casting, there are four passes before resolution; this is only a
    # bounded priority/stack scenario, not a full combat or MTG match.
    for i in (0,1,2,3):g.perform(i,{'kind':'pass','action_id':'pass'})
    trace=g.export_trace()
    trace['chosen_action']=choice
    trace['target_stack_id']=target
    return trace
