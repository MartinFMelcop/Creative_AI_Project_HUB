"""Explicitly bounded event-resolution experiment for a documented 2-card synergy.

NOT a Comprehensive Rules engine, Oracle verifier, or legal game simulator.
Given both permanents in play, a draw event generates Sheoldred (gain 2)
then Master's triggered draw(2). Drawing from an empty library generates
no further Sheoldred trigger; Master's 'cannot lose' protects from decking.
Interruption windows and APNAP multiple-controller ordering are NOT modeled.
"""
from dataclasses import dataclass

@dataclass
class Result:
    actual_cards_drawn: int
    failed_draw_attempts: int
    life_gained: int
    life_total: int
    opponents_remaining: tuple[int, int, int]
    emptied_library: bool
    cannot_lose_to_decking: bool
    limited_card_win: bool
    triggers_resolved: int


def resolve_bounded_draw_chain(*, deck_size: int, life: int = 40,
                               opponents=(40,40,40), crawler: bool=False,
                               mastery: bool=True, sheoldred: bool=True,
                               initial_draws: int=1) -> Result:
    if deck_size < 0 or initial_draws < 0 or len(opponents)!=3:
        raise ValueError('invalid test scenario')
    waiting=[('draw',initial_draws)]
    remaining=deck_size; drawn=failed=triggers=0;gained=0; enemies=list(opponents)
    # Every successful draw adds at most 1 Sheoldred and 1 Crawler trigger;
    # every Sheoldred gain adds 1 Mastery trigger. Finite deck => finite events.
    while waiting:
        kind,n=waiting.pop()
        if kind=='draw':
            successful=min(remaining,n);remaining-=successful;drawn+=successful;failed+=n-successful
            for _ in range(successful):
                if crawler:waiting.append(('crawler',1))
                if sheoldred:waiting.append(('gain',2))
        elif kind=='gain':
            life+=n;gained+=n;triggers+=1
            if mastery:waiting.append(('draw',n))
        elif kind=='crawler':
            enemies=[x-1 for x in enemies];triggers+=1
        else:raise ValueError('unsupported event')
    return Result(drawn,failed,gained,life,tuple(enemies),remaining==0,
                  mastery,all(x<=0 for x in enemies),triggers)


def oracle_endgame_ready(*, library_remaining: int, oracle_in_hand: bool,
                         can_cast_sorcery: bool, blue_mana: int,
                         sheoldred_mastery_trigger_stack_empty: bool) -> bool:
    """Only one condition of a potential Thassa's Oracle finishing line.
    Does not enumerate priority, opponent interaction, cast costs beyond U U.
    """
    return (library_remaining==0 and oracle_in_hand and can_cast_sorcery and
            blue_mana>=2 and sheoldred_mastery_trigger_stack_empty)
