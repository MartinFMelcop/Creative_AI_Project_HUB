# CommanderSIM — current-only engineering increment

## Scope and source of truth

Exactly four operational `decks/*.txt` files (100 cards each, with five immutable commander cards across the four lists). No original-list archives, replacement history, candidate-branch decks or copied prior reports are shipped. No card substitutions were made in this increment: engineering correctness comes first. Abzan remains protected.

**This package contains two different execution levels, never to be conflated:**

1. **30,000 four-seat SURROGATE_ONLY abstract games**, 15,000 per frozen-heuristic and threat-aware policy, current identical lists, matched seeds, starting seat randomized. These *do not* implement Magic cards' Oracle instructions.
2. **Six BOUNDED_NOT_FULL_GAME deterministic scenarios**, using an executable legal-action/priority/stack slice for some concrete cards. Two scenarios have a fixture winner, which is not a completed Magic match. No integrated Oracle-verified matches were run (**0**).

The `reports/current_kpis.json` file provides sample sizes, paired uncertainty, P90/P99 turns, win rates and 25% gaps. The `reports/bounded_combo_scenarios.json` file contains event-level traces. The full raw surrogate card/event statistics reside in `reports/surrogate_policy_pair_v16.json`.

## Actual rule-engine improvements

`engine/stack_combo_slice.py` adds a **limited** four-player priority/trigger engine on top of source-validated deck construction:

- Independent seat observations and legal-action filtering; PASS is available. Deterministic priority passing, adapted to eliminated players; four-pass stack resolution in four-active-player fixtures.
- Colored mana payment: Lich's Mastery `{3}{B}{B}{B}`, Sheoldred `{2}{B}{B}`, Thassa's Oracle `{U}{U}`, Psychosis Crawler `{5}`, Generous Gift `{2}{W}`, overloaded Cyclonic Rift `{6}{U}`.
- Sheoldred's triggers for a controller or opponent drawing a card; Lich's Mastery life-gain/card-draw chain, inability to lose, leave-the-battlefield loss trigger, limited deterministic exile choices; Psychosis Crawler's per-card opponent life loss.
- Thassa's Oracle ETB trigger with devotion recalculated at *resolution*; response from Generous Gift can remove Oracle in advance. Lich's Mastery hexproof correctly prevents opponents' targeting with Generous Gift, while overloaded Cyclonic Rift can still bounce it.
- State-based check handles failed empty-library draws **only at the corresponding check**, preventing obsolete loss conditions from persisting forever. Controlled fixture interruption is not reported as a real draw.
- Explicit, restricted fixture setup. No invented Oracle resolution when a card or effect is unsupported.

**Not supported:** real mulligans, turn progression, land untapping and abilities, arbitrary cards, full APNAP choices, spells outside the subset, general target changes, exhaustive replacement effects/layers, full combat, full commander mechanics, comprehensive win/draw adjudication, general infinite loops, rules-engine integration or complete Commander matches. Fixture placements bypass natural acquisition/casting; these are NOT game results. Within one controller, simultaneous trigger order uses a fixed testing convention, not a general player-choice interface. This is **not** Forge or XMage.

Official starting points for verification: https://magic.wizards.com/en/rules and https://magic.wizards.com/en/news/feature/dominaria-release-notes. For card lookups see `reports/card_source_ledger.json`. **0/299 unique names were retrieved through Scryfall API here**; the ledger labels these UNVERIFIED_SCRYFALL. Publicly confirmed selected interaction texts are not equivalent to full API validation.

## Windows PowerShell / Linux commands

Requirements: Python 3.10+ and C++17 g++ (MSYS2 UCRT64 on Windows). No package installation required for the Python rule-slice/tests.

```powershell
# Run in package root from PowerShell
python -m unittest discover -s tests -v
python scripts/verify_combo_scenarios.py
.\build_windows.ps1
```

```bash
# Run from package root in Linux
python -m unittest discover -s tests -v
python scripts/verify_combo_scenarios.py
g++ -O3 -std=c++17 engine/surrogate.cpp -o engine/simulate
COMMANDERSIM_AUDIT_MODE=1 ./engine/simulate . 15000 -1 260000000 reports/surrogate_policy_pair_v16.json
python scripts/build_current_reports.py
```

For Scryfall validation on a network-enabled machine, run `python scripts/scryfall_audit.py`. Review its unresolved list, Commander legality and partner/color rules **before** claiming deck-wide verification.

## Interpretation

The objective is approximately 25% observed win rate for each deck, not a reason to force it. The empirical values in `reports/current_kpis.json` compare *policy behavior on the same lists*, **not** deck upgrades. Paired confidence intervals measure uncertainty under this approximate model, not rule accuracy. No card changes can be certified from this increment. Improving Oracle rule fidelity is the primary priority before expensive new deck optimization.
