# AI Consumption Brief — v10 (Navigation Only)

**Status:** `V10_RELEASE_CANDIDATE_PENDING_G8`. **Authority:** none. Canonical, editable source: `knowledge/commander-simulation-research.md`; use that file for evidence and never import this brief as a second Brain, laboratory, decision register or `docs/STATE.md` replacement.

## Reading route

1. Read the canonical authority contract and Executive Decision first. For ownership consult Section 6; for actual source boundaries Section 2; for statistical/AI claims Section 3; for actionable research protocols Section 4; for external citations Section 10; for release status Section 9.
2. Preserve the source labels `OBSERVED_SOURCE`, `RECORDED_EXECUTION`, `EXTERNAL_METHOD`, `INFERENCE` and `PROPOSED_EXPERIMENT`. A code method, a historical result and a future proposal are not interchangeable.
3. Choose a new experimental contribution only through the HUB's existing adaptive process; compare P09 Unity/Windows obligations and North Star product needs before accepting the P01/P02 pilot.

## Decisive facts

- P01 Eclipse Fair already has a four-person deterministic owner: `projects/eclipse-fair/Core/{Game,Agents,Planning}.cs` and `Checks/Program.cs`. Policies call `Legal()` and `Apply()`; forecasts operate on forks and are conditional. `Seed` jointly influences initial positions, initiative and environmental events. Multiwinner ties exist at the round-limit.
- P02 AI Evaluation can contribute calibration and candidate/evaluator separation, but has **not** run a game-agent evaluation in this study.
- P06 CombatStudy has scripted pressure, six attempted actions (`strike`, `bash`, `guard`, `treat`, `cleanse`, `retreat`), distinct terminal outcomes and no adaptive opponent AI. P05 Crossing/Loadout contains original experimental build choices, not approved MMORPG classes.
- CommanderSIM v0.16: 30,000 **abstract surrogate** episodes; zero complete verified Magic Commander games. The observed ~41.2% Abzan surrogate win rate is not a North Star fairness result.
- 11 HUB laboratories, not 12; P09 `build-operations` remains `incomplete`. Keep protected Brains intact. Unity/C# is selected; Unity Editor, Windows Player and Steam end-to-end proof must remain separate.

## Proposed experiment, not actual execution

One scoped P01/P02 evaluation uses a frozen observation schema, legal-action-only candidate, exact source hashes, a named fixed scenario-family corpus, held-out opponent rosters, independent evaluator and per-game tie-aware scores (`1/k` for each of `k` listed winners). Do not infer pure initiative effects from permuting policies alone. Stop and report negative/inconclusive when an invariant, holdout, provenance or model-validity gate fails. Only then consider transferring *methods* into P06 and P05, with new tests for those **different** owners.

## Not proven

No implemented new policy, trained RL agent, changed deck, complete Magic game, Unity gameplay build, new player study, independent review, or authorized GitHub publication follows from v10 editorial checks.

## Editorial gate

G1-G7 may pass documentary/machine QA. **G8 independent consuming AI reader is not performed by the authoring model.** A separate reviewer must answer Q1-Q5 from the canonical Markdown alone; evaluator holds back the expected answers. Until then, do not call this `FINAL_FOR_RESEARCH_CONSUMPTION`. Once G8 passes and its evidence is recorded, no v11 is required absent a substantive defect or changed sources.
