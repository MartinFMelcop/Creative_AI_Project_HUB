# Independent AI Reader Handoff — v10

## Separation requirement

Use a **fresh, independent AI session/agent** without access to the authoring conversation, answer key, earlier candidate answers, or any private evaluator notes. Provide exactly the canonical `knowledge/commander-simulation-research.md` file, this prompt, and no other context. Record model identity, document SHA-256, date, input scope, allowed tools and exact response. Do not ask the authoring model to impersonate this reviewer.

## Reviewer instruction

Read the attached research document as a potentially imperfect research proposal. Answer Q1-Q5 **from the document only**, without filling gaps from general memory. For each answer cite the relevant section identifier, label evidence (`OBSERVED_SOURCE`, `RECORDED_EXECUTION`, `EXTERNAL_METHOD`, `INFERENCE`, `PROPOSED_EXPERIMENT`) and state the largest important limitation. If the document is contradictory, quote the conflicting section labels and classify the document as `BLOCKED`. Do not read or request the withheld scoring key. Reply as valid JSON with `answers` (array of objects with fields `id`, `answer`, `support`, `evidence_level`, `limit`), `critical_errors` (array), and `verdict` (`PASS` or `BLOCKED`).

## Questions

Q1. Which current HUB lab(s) and actual classes own the proposed first policy comparison? Is that experiment automatically the next mandatory implementation?

Q2. Can the observed CommanderSIM v0.16 Abzan percentage establish real Commander deck performance or North Star build fairness? Supply the completed rules-verified-game denominator.

Q3. What variables are tied to `Seed` in Eclipse Fair? Does permuting policy identities within a fixed seed isolate pure first-player advantage? How is a tied winner set scored?

Q4. Does CombatStudy already have an adaptive opponent? What is its `retreat` outcome, and what must be executed before stating a new combat AI is integrated into North Star?

Q5. A teammate says to create a twelfth lab, install Unity ML-Agents immediately, and classify the AI as integrated after 10,000 surrogate matches. Which claims or instructions should you reject and why?

**Do not include expected answers in the reviewer context.** Hand results back to an evaluator that has the separately stored key and scores support and factual correctness. A regex match alone cannot certify model comprehension.
