# CommanderSIM -> Creative AI Project HUB | v10 handoff

This is an **editorially consolidated research release candidate**, not an executed simulator enhancement and not proof of any North Star AI integration.

## Contents and intended placement

- `knowledge/commander-simulation-research.md` — the **only** candidate file for copying into the HUB maintained `knowledge/` directory.
- `release/CommanderSIM_Research_Transfer_v10.pdf` — offline formatted reading copy; **not** an authority source.
- `release/AI_CONSUMPTION_BRIEF_v10.md` — optional short navigation, external to the HUB and not a separate Brain/decision/protocol authority.
- `release/AI_READER_REVIEW_PROTOCOL_v10.md` — provide to a **fresh independent reader with the canonical Markdown only**; NEVER supply evaluator expected answers to that reader.
- `release/AI_READINESS_AUDIT_v10.json` — evidence status and gate outcomes, G8 explicitly pending.
- `release/check_v10.py` — source contract and negative-control **mechanical checks only**, not AI semantic validation.
- `release/INTEGRATION_MANIFEST_v10.json` and `release/SHA256SUMS` — cryptographic integrity inventory.

## Exact follow-up

Read root/workspace AGENTS, current process, STATE and catalog before integration. This study should not override the current project priorities. Do not silently update protected Brains or assert new lab capability; it is derived-knowledge research only. A separate reviewer must answer the five scoped questions in a fresh context and pass the withheld evaluator key before calling the document `FINAL_FOR_RESEARCH_CONSUMPTION`.

No new agent simulations, actual full Commander games, Unity Editor/Windows player tests, human studies, GitHub commits or publication were performed as part of this v10 document release.
