#!/usr/bin/env python3
"""Mechanical source-contract and packaging checks; NOT an independent AI review."""
from pathlib import Path
import hashlib, json, re, sys

ROOT=Path(__file__).resolve().parent.parent
DOC=ROOT/'knowledge/commander-simulation-research.md'
REPORT=ROOT/'release/AI_READINESS_AUDIT_v10.json'

def check(text: str) -> dict:
    references = {m.group(1):m.group(2) for m in re.finditer(r'^\[([A-Z][A-Z0-9_-]+)\]:\s*(https?://\S+)', text,re.M)}
    found=set(re.findall(r'\[([EH]-[A-Z0-9_-]+)\]',text))
    missing=found-references.keys()
    if missing: raise AssertionError(f'Undefined reference: {sorted(missing)}')
    if len([r for r in references if r.startswith('E-')])!=17:raise AssertionError('Expected 17 external reference definitions')
    if len([r for r in references if r.startswith('H-')])!=15:raise AssertionError('Expected 15 internal reference definitions')
    required={
    'scope':'zero complete verified Commander games',
    'status':'V10_RELEASE_CANDIDATE_PENDING_G8',
    'independent_gate':'NOT EXECUTED in this authoring context',
    'seed':'Seed % 4',
    'seed_positions':'seed % 8',
    'tie':'fractional winner credit',
    'actions':'Game.Legal',
    'build':'PreparedExpedition',
    'lab':'build-operations',
    'threat':'CombatStudy',
    'g8':'Q5',
    'protected':'protected Brains'
    }
    missing_terms=[key for key,val in required.items() if val.lower() not in text.lower()]
    if missing_terms:raise AssertionError('Missing material contract text: '+', '.join(missing_terms))
    sections=re.findall(r'^## ([1-9]|10)\.',text,re.M)
    if sections != [str(i) for i in range(1,11)]:raise AssertionError(f'Unstable sections: {sections}')
    if any(phrase.lower() in text.lower() for phrase in ['g8 — handoff test | **pass**','G8 independent AI reader: passed']):raise AssertionError('False G8 completion')
    # This is only a source/consistency check; semantic correctness requires another reviewer.
    return {'reference_definitions':len(references),'external':17,'hub':15,'numbered_sections':len(sections),'concept_probes':len(required), 'sha256':hashlib.sha256(text.encode('utf-8')).hexdigest()}

def main():
    s=DOC.read_text(encoding='utf-8')
    result=check(s)
    # Verify a deliberately introduced negative control fails the same test.
    altered=s.replace('V10_RELEASE_CANDIDATE_PENDING_G8','RELEASED_WITHOUT_INDEPENDENT_REVIEW')
    try:check(altered)
    except AssertionError:result['negative_control']='detected_missing_status'
    else:raise AssertionError('Negative control was not rejected')
    print(json.dumps({'status':'pass_mechanical_checks_only',**result},indent=2))
    if REPORT.exists():
        audit=json.loads(REPORT.read_text(encoding='utf-8'))
        if audit['gates']['G8_independent_reader']['status']!='NOT_EXECUTED':raise AssertionError('False independent reader gate')
        if audit['source']['sha256']!=result['sha256']:raise AssertionError('Source digest differs from QA')
if __name__=='__main__':main()
